'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const catalog=require('./ui/catalog-model.js');
const settingsModel=require('./ui/settings-model.js');
const groups=require('./ui/catalog-groups.js');
const empty=()=>({format:'criae3d-utilities',schema:1,settings:{company:{},theme:'default',colors:{}},clients:[],quotes:[],products:[],draft:null});
function validate(data){
 data=groups.migrate(data);groups.validate(data);
 if(data?.settings?.profile!==undefined){const profile=data.settings.profile;if(!profile||typeof profile!=='object'||Array.isArray(profile)||typeof profile.name!=='string'||!profile.name.trim()||profile.name.length>80||/[\x00-\x1f\x7f]/.test(profile.name))throw Error('Nome do espaço de trabalho inválido.');}
 if(!data||data.format!=='criae3d-utilities'||data.schema!==1)throw Error('Formato de backup incompatível.');
 if(!data.settings||!data.settings.company||typeof data.settings.company!=='object'||Array.isArray(data.settings.company)||!data.settings.colors||typeof data.settings.colors!=='object'||!['default','light','dark','custom'].includes(data.settings.theme)||!Array.isArray(data.clients)||!Array.isArray(data.quotes)||data.clients.length>10000||data.quotes.length>10000)throw Error('Dados inválidos ou limite excedido.');
 if(data.products!==undefined&&(!Array.isArray(data.products)||data.products.length>10000))throw Error('Catálogo inválido ou limite excedido.');
 const productIds=new Set();for(const product of data.products||[]){catalog.validate(product);catalog.sale(product,1);if(productIds.has(product.id))throw Error('Produto duplicado no catálogo.');productIds.add(product.id);}
 for(const list of [data.clients,data.quotes]){const ids=new Set();for(const entry of list){if(!entry||typeof entry.id!=='string'||!entry.id||ids.has(entry.id))throw Error('Cadastro inválido ou duplicado.');ids.add(entry.id);}}
 for(const client of data.clients)if(typeof client.name!=='string'||!client.name.trim())throw Error('Nome de cliente inválido.');
 const validateDraft=draft=>{if(draft?.companySnapshotKey!==undefined&&(typeof draft.companySnapshotKey!=='string'||!Object.hasOwn(data.settings.companyProfiles||{},draft.companySnapshotKey)))throw Error('Dados de empresa do orçamento ausentes.');if(!draft||!Array.isArray(draft.items)||draft.items.length>100||!draft.data||!draft.data.show)throw Error('Rascunho inválido.');for(const item of draft.items){if(typeof item.name!=='string'||item.name.length>120||!Number.isSafeInteger(item.quantity)||item.quantity<1||item.quantity>1000000||!/^\d{1,50}$/.test(item.total?.n||'')||!/^\d{1,50}$/.test(item.total?.d||'')||BigInt(item.total.d)===0n)throw Error('Produto de orçamento inválido.');}};
 if(data.draft!==null)validateDraft(data.draft);for(const quote of data.quotes){validateDraft(quote.draft);if(!/^\d{1,50}$/.test(quote.total||'')||!Number.isFinite(Date.parse(quote.createdAt)))throw Error('Histórico inválido.');}
 for(const quote of data.quotes)if(quote.status!==undefined&&!['draft','sent','approved','cancelled'].includes(quote.status))throw Error('Status de orçamento inválido.');
 for(const key of ['seenRelease'])if(data.settings[key]!==undefined&&(typeof data.settings[key]!=='string'||!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z]+(?:[.-][0-9A-Za-z]+)*)?$/.test(data.settings[key])))throw Error('Versão inválida.');
 if(data.settings.accent!==undefined&&!['lilac','blue','green','teal','terra','graphite','violet','pink','red','orange','gold','olive','mint','sky','indigo','wine','custom'].includes(data.settings.accent))throw Error('Cor de destaque inválida.');
 if(data.settings.defaults!==undefined){if(!data.settings.defaults||typeof data.settings.defaults!=='object'||Array.isArray(data.settings.defaults))throw Error('Padrões da calculadora inválidos.');settingsModel.calculator(data.settings.defaults);}
 if(data.settings.companyProfiles!==undefined&&(!data.settings.companyProfiles||typeof data.settings.companyProfiles!=='object'||Array.isArray(data.settings.companyProfiles)||Object.entries(data.settings.companyProfiles).some(([key,value])=>!key||!value||typeof value!=='object'||Array.isArray(value))))throw Error('Histórico de empresa inválido.');
 if(data.settings.quoteDefaults!==undefined)settingsModel.quote(data.settings.quoteDefaults);
 if(data.settings.customAccent!==undefined&&!/^#[0-9a-f]{6}$/i.test(data.settings.customAccent))throw Error('Cor personalizada inválida.');
 if(data.settings.toolIntroDismissed!==undefined){const value=data.settings.toolIntroDismissed;if(!value||typeof value!=='object'||Array.isArray(value)||Object.entries(value).some(([k,v])=>!['quotes','clients','products','backup'].includes(k)||typeof v!=='boolean'))throw Error('Preferências de apresentação inválidas.');}
 if(data.settings.calculatorIntroDismissed!==undefined&&typeof data.settings.calculatorIntroDismissed!=='boolean')throw Error('Preferência da calculadora inválida.');
 if(data.settings.quotePreview!==undefined&&typeof data.settings.quotePreview!=='boolean')throw Error('Preferência de prévia inválida.');
 if(data.settings.openingAnimations!==undefined&&typeof data.settings.openingAnimations!=='boolean')throw Error('Preferência de abertura inválida.');
 if(data.settings.reduceMotion!==undefined&&typeof data.settings.reduceMotion!=='boolean')throw Error('Preferência de movimento inválida.');
 if(data.settings.appearanceReady!==undefined&&typeof data.settings.appearanceReady!=='boolean')throw Error('Preferência de aparência inválida.');
 if(data.settings.tourSeen!==undefined&&typeof data.settings.tourSeen!=='boolean')throw Error('Preferência de apresentação inválida.');
 if(Buffer.byteLength(JSON.stringify(data))>20*1024*1024)throw Error('Dados excedem 20 MB.');
 return JSON.parse(JSON.stringify({...data,products:data.products||[]}));
}
class Store{
 constructor(directory){this.directory=directory;this.file=path.join(directory,'dados.json');fs.mkdirSync(directory,{recursive:true});fs.mkdirSync(path.join(directory,'backups'),{recursive:true});this.data=fs.existsSync(this.file)?validate(JSON.parse(fs.readFileSync(this.file,'utf8'))):empty();}
 read(){return structuredClone(this.data);}
 write(data){const next=validate(data),temporary=this.file+'.tmp';fs.writeFileSync(temporary,JSON.stringify(next,null,2),'utf8');fs.renameSync(temporary,this.file);this.data=next;return this.read();}
 backup(){const name='Backup-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomBytes(3).toString('hex')+'.json';const file=path.join(this.directory,'backups',name);fs.writeFileSync(file,JSON.stringify(this.data,null,2));return file;}
 restore(data){validate(data);const backup=this.backup();this.write(data);return {backup,data:this.read()};}
 usage(){const bytes=file=>fs.statSync(file).size;let backups=0,lastBackup=null;for(const f of fs.readdirSync(path.join(this.directory,'backups'))){const file=path.join(this.directory,'backups',f),stat=fs.statSync(file);if(!stat.isFile())continue;backups+=stat.size;if(!lastBackup||stat.mtimeMs>lastBackup.time)lastBackup={name:f,createdAt:stat.mtime.toISOString(),time:stat.mtimeMs};}return {directory:this.directory,data:fs.existsSync(this.file)?bytes(this.file):0,backups,lastBackup};}
}
module.exports={Store,empty,validate};
