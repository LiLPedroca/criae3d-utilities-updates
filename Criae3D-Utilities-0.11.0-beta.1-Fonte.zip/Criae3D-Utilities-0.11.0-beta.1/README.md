# Criae3D Utilities 0.11.0-beta.1

Beta de desenvolvimento com nova interface e criadores locais. Consulte [mudanças e limites](docs/0.11.0-beta.1.md). Nenhuma release desta beta foi publicada.

# Criae3D Utilities 0.10.0

Criador de chaveiros de nome em Beta, prévias 2D/3D, três fontes locais, bases e argola interativa, exportação 3MF multicor e integração com fatiadores. Ferramentas e dados anteriores preservados. Consulte keychain/README.md para geometria, licenças e limites.

## Executar e compilar

Requer Node.js e npm no Windows. Execute `npm ci`, `npm run build:keychain`, `npm test`, `npm start` e `npm run dist`. Electron 43.7.9 e electron-builder 26.15.3 estão fixados. O instalador NSIS e os arquivos para atualização são gerados em `dist`. O identificador do aplicativo foi mantido. Nenhuma publicação automática é feita.

## Testes de interface

Além dos 59 testes de `npm test`, o roteiro `node tests/interface.cjs` usa Playwright e Electron para percorrer os formulários com dados fictícios e falha simulada de disco. Instale Playwright no ambiente de desenvolvimento ou informe o caminho do pacote em CRIAE3D_PLAYWRIGHT. CRIAE3D_ELECTRON pode apontar para um executável Electron já instalado. Os artefatos ficam em tests/artifacts. O teste não acessa cadastros reais nem envia e-mails.

## Compatibilidade dos dados

O formato principal continua schema 1. Dados antigos ganham catálogos por categoria; itens sem categoria entram em Geral. IDs e campos existentes são preservados. Produtos em orçamentos são cópias independentes: alterar o catálogo não altera pedidos anteriores. A preferência de prévia fica em settings.quotePreview, assumindo true quando ausente. O desconto fica no rascunho e no histórico, sem alterar produtos. Backups completos incluem catálogos.

## Origem

Esta versão parte do código 0.6.0 recuperado do aplicativo instalado. A configuração de desenvolvimento e compilação foi reconstruída; a base anterior foi preservada separadamente. A calculadora nativa 0.5/0.6 foi mantida e aparece novamente nas novidades desta renovação.

## Verificação de fechamento e apresentações

`node tests/experience.integration.cjs` executa o processo principal real com perfil de dados isolado. Verifica as quatro apresentações, persistência, Escape, falha de gravação, cancelamento do fechamento, backup antes de descartar, espera de gravações, reinício e compatibilidade com o fluxo de atualização. Usa as mesmas variáveis CRIAE3D_PLAYWRIGHT e CRIAE3D_ELECTRON descritas acima. CRIAE3D_TEST_APP permite testar o app.asar empacotado. Nenhum instalador real é executado pelo roteiro.


## Conversor SVG beta

Conversão local monocromática de PNG, JPG, WebP e BMP. Ajustes de limiar, inversão, suavização, filtro de pontos e largura de 1 a 2000 mm; altura proporcional ao desenho útil sem margens. Limite de entrada 20 MB/40 megapixels, processamento limitado a 2,4 megapixels e 4096 px por lado, sem redução quando a imagem já cabe nesses limites. Não há limite de quantidade de conversões. Não reconstrói detalhes perdidos nem transforma fotos em vetores fiéis; partes separadas não são unidas. Importação de um vetor de teste em Anycubic Slicer Next 2.0.0.3 e OrcaSlicer foi verificada com 140 × 50 mm e furo interno; não houve impressão física.

A imagem não é enviada à rede. Web Worker cancelável mantém a interface disponível. SVG exporta caminhos vetoriais sem bitmap incorporado. ImageTracer.js 1.2.6, de András Jankovics, distribuído sob Unlicense: https://github.com/jankovicsandras/imagetracerjs . Código e licença em ui/vendor.

Testes: node tests/svg.interface.cjs (prévia rasterizada e exportação simulada) e node tests/svg.integration.cjs (main/IPC real em perfil isolado). CRIAE3D_TEST_APP permite executar o app.asar em desenvolvimento. A importação e extrusão no fatiador e a instalação real devem ser verificadas separadamente.


## Medidas e movimento — 0.8.1

Escolha mm/cm; largura e altura do desenho são editáveis. Manter proporção vem ativado e, ao ser reativado, preserva a proporção atual. A prévia já convertida é redimensionada sem refazer a vetorização. Exportação sempre em mm, com preserveAspectRatio=none para respeitar dimensões independentes. Limite por eixo 1–2000 mm (0,1–200 cm). Espessura/extrusão continuam no fatiador.

Interruptores usam o estado nativo :checked com transição CSS, eliminando a fila de segmentos Lottie; redução de movimento cancela animações ativas e pausa players. Sistema operacional continua tendo prioridade por acessibilidade. Botão principal do SVG tem fundo e texto explícitos em todos os estados.

node tests/refinements.interface.cjs verifica unidades, cadeado, prévia, exportação, limites, tema escuro, alternâncias de movimento, persistência, rollback de falha de gravação e preferência do sistema. Novidades apresentam fim da beta e duas ferramentas novas como intenção/previsão da equipe, sem garantia de prazo ou ausência total de erros.


## Meu fatiador e prévia ao vivo — 0.9.0

Cadastro local de Anycubic Slicer Next, OrcaSlicer, Bambu Studio, UltiMaker Cura, PrusaSlicer e Creality Print. Busca limitada a pastas comuns e registro de instalação; não varre o disco inteiro. Escolha manual de executável conhecido, seleção múltipla, principal e troca pelo painel no cabeçalho. Ícones oficiais e origens em ui/assets/slicers/ORIGEM.md.

Preferências em slicers.json, separadas dos cadastros e backups de trabalho. Cópias enviadas ficam em Envios SVG no diretório local do aplicativo; não são apagadas automaticamente para manter referências do projeto abertas no fatiador.

Envio direto de SVG validado nos dois aplicativos disponíveis (Anycubic Next e Orca). Antes de enviar, o programa verifica a preferência de instâncias separadas, ou confirma que o processo está fechado. Quando não pode garantir uma sessão separada, oferece Exportar SVG. Bambu, Cura, Prusa e Creality têm detecção/cadastro/abertura, mas usam exportação manual para o SVG até validação própria. A mensagem de sucesso informa somente que a abertura foi solicitada: confira a importação e as medidas no destino. Não se altera a configuração do fatiador nem se confirma sincronização de perfis na nuvem.

A geometria do SVG é normalizada em milímetros e sem margens; viewBox e coordenadas acompanham largura/altura, inclusive redimensionamento independente. Ajustes de contorno refazem a prévia automaticamente com debounce e descarte de trabalhos antigos. Inversão inicia desligada. Dimensões são 2D; profundidade e ajustes de impressão continuam no fatiador.

Seletores de imagens (conversor e logo da empresa) usam cartão clicável e cores do tema. Arquivos de backup/documentos mantêm seus próprios fluxos.

Testes adicionais: tests/live-slicers.interface.cjs (painel e prévia com processos simulados) e tests/slicers.integration.cjs (main/preload real, instalações locais, cadastro e reinício em perfil isolado, sem iniciar fatiadores). Testes de detecção dos quatro fatiadores não instalados são simulados, não validação prática de importação. A atualização sobre instalação existente não é executada pelos testes.


## Fidelidade — 0.9.1

Correção local em ImageTracer 1.2.6: oito chamadas de roundtodec nos caminhos de furos passam a receber options.roundcoords, assim como o contorno externo. Isso evita arredondar furos para milímetros inteiros após a normalização física. Alteração indicada no cabeçalho do arquivo; licença Unlicense preservada.

Alta fidelidade (tolerância 0,1) é o novo padrão. As opções anteriores continuam disponíveis. A máscara é recortada na região útil com borda branca de guarda antes de traçar, preservando pixels de origem e reduzindo trabalho em imagens com margens. Bounds retornam às coordenadas da imagem original. O canvas Original mostra a mesma região útil e proporção do vetor; svgSource continua com os pixels de origem para refazer os ajustes sem degradação acumulada.

Validação local com logo JPG fornecido pelo usuário: cinco contornos preservados; na comparação binária alinhada ao original, diferenças passaram de 3507 pixels (0.9.0) para 4 (0.9.1), IoU de 0,97350 para 0,99997. Resultado específico desta imagem, limiar 128 e renderização Chromium; não é garantia para outras imagens nem equivalência de cores/antialiasing. Foto original não é incluída no código/fonte publicado. Testes públicos usam figuras sintéticas, incluindo furos com medidas fracionárias e contato com as bordas.
