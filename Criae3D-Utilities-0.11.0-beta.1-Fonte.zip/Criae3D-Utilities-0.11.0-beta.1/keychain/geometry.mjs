// All dimensions are millimetres. This module also runs in the dedicated UI worker.
import {fontFamilies} from './fonts.mjs';
export const defaults={name:'Personalize',font:'Lobster',width:70,border:2.4,base:2.4,raise:1.2,style:'contour',eyelet:0.52,hole:4,ring:2,baseColor:'#243449',textColor:'#4169e1'};
export const presets={delicado:{font:'Pacifico',border:2,base:2,raise:1},classico:{font:'Lobster',border:2.4,base:2.4,raise:1.2},robusto:{font:'LilitaOne',border:3,base:3,raise:1.6}};
export function validateOptions(v){
 const o={...defaults,...v};if(o.eyelet===undefined)o.eyelet=defaults.eyelet;o.name=String(o.name).normalize('NFC').trim();
 if(!o.name||o.name.length>32||/[\x00-\x1f]/.test(o.name))throw Error('Digite um nome de 1 a 32 caracteres.');
 if(!fontFamilies.includes(o.font)||!['contour','capsule','rounded'].includes(o.style))throw Error('Fonte ou base inválida.');
 for(const [key,min,max]of [['width',.1,250],['border',1.2,8],['base',1.2,8],['raise',.4,5],['hole',3,8],['ring',1.6,5],['eyelet',0,1]])if(!Number.isFinite(o[key])||o[key]<min||o[key]>max)throw Error('Medida inválida: '+key+'.');
 for(const key of ['baseColor','textColor'])if(!/^#[a-f\d]{6}$/i.test(o[key]))throw Error('Cor inválida.');return o;
}
const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
export function nearestOnLoop(loop,p){let best=null,total=0;const lengths=loop.map((a,i)=>distance(a,loop[(i+1)%loop.length]));const perimeter=lengths.reduce((a,b)=>a+b,0);loop.forEach((a,i)=>{const b=loop[(i+1)%loop.length],dx=b[0]-a[0],dy=b[1]-a[1],len=lengths[i];if(!len)return;const t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(len*len))),q=[a[0]+t*dx,a[1]+t*dy],d=distance(q,p);if(!best||d<best.distance)best={point:q,distance:d,t:(total+t*len)/perimeter};total+=len;});return best;}
export function pointOnLoop(loop,t){const lengths=loop.map((a,i)=>distance(a,loop[(i+1)%loop.length])),perimeter=lengths.reduce((a,b)=>a+b,0);let remaining=((t%1)+1)%1*perimeter;for(let i=0;i<loop.length;i++){const len=lengths[i];if(remaining<=len&&len>0){const a=loop[i],b=loop[(i+1)%loop.length];return {point:[a[0]+(b[0]-a[0])*remaining/len,a[1]+(b[1]-a[1])*remaining/len],normal:[(b[1]-a[1])/len,-(b[0]-a[0])/len]};}remaining-=len;}throw Error('Contorno inválido.');}
export function flatPath(commands,tolerance){const loops=[];let loop=[],p=[0,0],start=p;const add=q=>{if(!loop.length||distance(loop.at(-1),q)>1e-7)loop.push(q);p=q;};const curve=(points,depth=0)=>{const a=points[0],b=points.at(-1),dx=b[0]-a[0],dy=b[1]-a[1],den=Math.hypot(dx,dy);const error=Math.max(...points.slice(1,-1).map(q=>den?Math.abs(dy*q[0]-dx*q[1]+b[0]*a[1]-b[1]*a[0])/den:distance(a,q)));if(error<=tolerance||depth>=12){add(b);return;}let levels=[points],left=[a],right=[b];while(levels.at(-1).length>1){const prev=levels.at(-1),next=prev.slice(1).map((v,i)=>[(v[0]+prev[i][0])/2,(v[1]+prev[i][1])/2]);levels.push(next);left.push(next[0]);right.unshift(next.at(-1));}curve(left,depth+1);curve(right,depth+1);};const close=()=>{if(loop.length>2){if(distance(loop[0],loop.at(-1))<1e-7)loop.pop();loops.push(loop);}loop=[];};
 for(const c of commands){const q=[c.x,-c.y];if(c.type==='M'){close();start=q;add(q);}else if(c.type==='L')add(q);else if(c.type==='Q')curve([p,[c.x1,-c.y1],q]);else if(c.type==='C')curve([p,[c.x1,-c.y1],[c.x2,-c.y2],q]);else if(c.type==='Z'){add(start);close();}}close();return loops;
}
function generateRaw(M,font,input){const o=validateOptions(input),owned=[],keep=x=>(owned.push(x),x),C=M.CrossSection,warnings=[];
 try{
 for(const ch of o.name)if(ch!==' '&&font.charToGlyphIndex(ch)===0)throw Error('A fonte não possui o caractere “'+ch+'”. Escolha outra fonte.');
 const path=fontPath(font,o.name),bb=path.getBoundingBox(),scale=o.width/(bb.x2-bb.x1);if(!Number.isFinite(scale))throw Error('O nome não possui contornos.');
 const loops=flatPath(path.commands,.02/scale).map(loop=>loop.map(([x,y])=>[(x-bb.x1)*scale,(y+bb.y2)*scale]));
 const text=keep(new C(loops,'NonZero'));if(text.area()<1)throw Error('Nome pequeno demais.');const bounds=text.bounds(),h=bounds.max[1]-bounds.min[1];if(h>300)throw Error('A altura do nome excede 300 mm. Reduza a largura.');if(h<4)warnings.push('O nome está baixo. Confira os traços finos antes de imprimir.');
 let base;
 if(o.style==='contour'){
 base=keep(text.offset(o.border,'Round',2,64));
 // Join separate accents, dots and words with the shortest rounded bridges.
 for(let pass=0;pass<48;pass++){
 const parts=base.decompose().map(keep);if(parts.length===1)break;if(pass===47)throw Error('Não foi possível unir a base. Use Cápsula ou Retangular.');
 const polygons=parts.map(part=>part.toPolygons().flat().filter((_,i,a)=>i%Math.max(1,Math.floor(a.length/150))===0));let best=null;
 for(let i=1;i<polygons.length;i++)for(const a of polygons[0])for(const b of polygons[i]){const d=distance(a,b);if(!best||d<best.d)best={a,b,d};}
 const r=Math.max(1.2,o.border*.7),ca=keep(C.circle(r,32).translate(best.a)),cb=keep(C.circle(r,32).translate(best.b)),bridge=keep(C.hull([ca,cb]));base=keep(base.add(bridge));
 }
 }else{
 const radius=o.style==='capsule'?h/2+o.border:o.border;
 const inner=keep(C.square([o.width,o.style==='capsule'?.01:h]).translate([0,o.style==='capsule'?h/2:0]));base=keep(inner.offset(radius,'Round',2,80));
 }
 const outer=base.toPolygons().sort((a,b)=>Math.abs(signedArea(b))-Math.abs(signedArea(a)))[0];if(signedArea(outer)<0)outer.reverse();
 if(input.eyelet===undefined)o.eyelet=nearestOnLoop(outer,[-1000,h/2]).t;
 const anchor=pointOnLoop(outer,o.eyelet),radius=o.hole/2+o.ring,overlap=Math.min(o.ring,2),center=anchor.point.map((v,i)=>v+anchor.normal[i]*(radius-overlap));
 const disc=keep(C.circle(radius,96).translate(center)),hole=keep(C.circle(o.hole/2,80).translate(center));
 if(keep(text.intersect(hole)).area()>.001)throw Error('A argola está sobre o texto. Arraste para outra posição na borda.');
 base=keep(keep(base.add(disc)).subtract(hole));const parts=base.decompose().map(keep);if(parts.length!==1)throw Error('A argola precisa ficar conectada à base. Escolha outra posição.');
 if(keep(text.subtract(base)).area()>.005)throw Error('Há texto sem apoio. Aumente a borda ou reposicione a argola.');
 if(keep(disc.intersect(keep(base.offset(-.5)))).area()<1)throw Error('Conexão da argola muito fina. Reposicione na borda.');
 if(o.base<1.6||o.border<1.6||o.raise<.6)warnings.push('Estrutura delicada: confira a resistência e a largura de linha do seu bico.');
 const core=keep(text.offset(-.21,'Round',2,32)),recover=keep(core.offset(.21,'Round',2,32));if(keep(text.subtract(recover)).area()/text.area()>.035)warnings.push('Há detalhes finos no texto. Confira a prévia das camadas no fatiador.');
 const solids=[keep(base.extrude(o.base)),keep(keep(text.extrude(o.raise)).translate([0,0,o.base]))];
 const meshes=solids.map((solid,i)=>{if(solid.status()!=='NoError'||solid.volume()<=0)throw Error('A geometria não pôde ser validada.');const mesh=solid.getMesh(),vertices=[];for(let v=0;v<mesh.vertProperties.length;v+=mesh.numProp)vertices.push(...mesh.vertProperties.slice(v,v+3));return {name:i?'Texto':'Base e argola',color:i?o.textColor:o.baseColor,vertices,triangles:Array.from(mesh.triVerts)};});
 const b=base.bounds();return {options:o,meshes,baseLoops:base.toPolygons(),textLoops:text.toPolygons(),perimeter:outer,eyelet:{center,radius,hole:o.hole/2,anchor:anchor.point},bounds:{min:b.min,max:b.max},dimensions:[b.max[0]-b.min[0],b.max[1]-b.min[1],o.base+o.raise],warnings};
 }finally{for(let i=owned.length-1;i>=0;i--)owned[i].delete();}
}
export function signedArea(loop){return loop.reduce((s,p,i)=>{const q=loop[(i+1)%loop.length];return s+p[0]*q[1]-p[1]*q[0];},0)/2;}

// Solve text width against the complete outline. Wall, hole and Z dimensions remain in mm.
export function generate(M,font,input={}) {
 const target=input.width??defaults.width;
 if(!Number.isFinite(target)||target<20||target>250)throw Error('Largura total: use de 20 a 250 mm.');
 let width=Math.max(1,target-2*(input.border??defaults.border)-6),result;
 for(let i=0;i<40;i++) {
  result=generateRaw(M,font,{...input,width});
  const error=target-result.dimensions[0];
  if(Math.abs(error)<.002) {
   result.options={...result.options,width:target};
   if(input.eyelet===undefined)delete result.options.eyelet;
   return result;
  }
  width*=target/result.dimensions[0];
  if(width<.1||width>250)break;
 }
 throw Error('O tamanho total não comporta esta estrutura. Aumente a largura ou reduza a borda/argola.');
}

// opentype.js 2 cannot shape some newer CCMP lookup formats. Precomposed Latin
// glyphs still have valid outlines; retain glyph kerning without unsupported substitutions.
export function fontPath(font,text) {
 try{return font.getPath(text,0,0,100,{kerning:true});}
 catch(error){
  if(!/substitutionType.*not yet supported/.test(error.message))throw error;
  const path=font.charToGlyph(text[0]).getPath(0,0,100);path.commands=[];let x=0,previous;
  for(const ch of text){const glyph=font.charToGlyph(ch);if(previous)x+=font.getKerningValue(previous,glyph)*100/font.unitsPerEm;path.commands.push(...glyph.getPath(x,0,100).commands);x+=(glyph.advanceWidth||0)*100/font.unitsPerEm;previous=glyph;}
  return path;
 }
}
