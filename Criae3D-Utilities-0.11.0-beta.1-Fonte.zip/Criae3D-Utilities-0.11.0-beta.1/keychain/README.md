# Chaveiro de nome

Geometria em milímetros com Manifold (WASM), curvas OpenType achatadas com tolerância de 0,02 mm e união NonZero. A geração acontece em Worker. O visualizador Three.js redesenha sob demanda e não refaz a geometria ao girar ou ampliar.

Fontes iniciais: Lobster, Pacifico e Lilita One, obtidas do repositório oficial google/fonts, diretórios ofl/lobster, ofl/pacifico e ofl/lilitaone. Licenças OFL acompanham os TTF em ui/assets/fonts. Licenças das bibliotecas acompanham os bundles em ui/keychain.

Depois de editar os módulos desta pasta, executar `npm run build:keychain` antes de testar e compilar o instalador. Não depende de CDN. A implementação usa Worker de módulo, WebAssembly e WebGL; quando o WebGL não está disponível a prévia 2D continua utilizável.

Na 0.11.0-beta.1, o campo Largura total do chaveiro dimensiona a extensão completa no eixo X, incluindo base e argola, com tolerância de cálculo inferior a 0,002 mm. Base, relevo, furo e parede continuam em milímetros e não são escalados por esse ajuste. As dimensões totais são mostradas na prévia. A seleção mm/cm converte os controles sem alterar a geometria física. Bases cápsula/retangular contêm o texto inteiro; bases de contorno unem ilhas com pontes arredondadas mínimas. A argola usa um parâmetro contínuo de comprimento do perímetro externo; posições que cortem o texto ou não tenham apoio são recusadas.

O 3MF contém duas malhas fechadas (base/argola e texto) como componentes de uma montagem, unidade millimeter e materiais distintos. Metadata/model_settings.config associa volumes aos slots 1 e 2 nos importadores Orca/Anycubic. Não inclui perfil de impressora, G-code ou credenciais. As cores exibidas dependem dos filamentos cadastrados no fatiador, que devem ser conferidos pelo usuário.

Salvar modelo está deliberadamente indisponível. Sem multipartes com encaixes/cola. A ferramenta permanece Beta: validação geométrica e fatiamento virtual não substituem uma prova física de impressão, resistência, aderência ou tolerâncias.

Testes: keychain.test.cjs, keychain-3mf.test.cjs, keychain.integration.cjs e keychain-slicers.interface.cjs. As integrações usam perfis isolados em tests/artifacts. Para verificar um app.asar com o Electron de desenvolvimento, definir CRIAE3D_TEST_APP para seu caminho absoluto.

A beta 0.11.0 acrescenta 15 fontes OFL locais, paletas e slots configuráveis. As origens/hashes estão em ui/assets/fonts/SOURCES.json. Consulte docs/0.11.0-beta.1.md para os novos criadores e seus limites.
