import factory from 'manifold-3d';
import opentype from 'opentype.js';
import {fontFamilies} from './fonts.mjs';
import {generate} from './geometry.mjs';
const fonts=new Map();let engine;
async function load(){engine=await factory({locateFile:()=>new URL('manifold.wasm',self.location.href).href});engine.setup();return engine;}
const ready=load();
self.onmessage=async({data})=>{try{await ready;const name=data.options.font||'Lobster';if(!fontFamilies.includes(name))throw Error('Fonte inválida.');if(!fonts.has(name)){const response=await fetch(new URL('../assets/fonts/'+name+'-Regular.ttf',self.location.href));if(!response.ok)throw Error('Não foi possível carregar a fonte.');fonts.set(name,opentype.parse(await response.arrayBuffer()));}const start=performance.now(),result=generate(engine,fonts.get(name),data.options);self.postMessage({id:data.id,ok:true,result,elapsed:performance.now()-start});}catch(e){self.postMessage({id:data.id,ok:false,message:e.message||'Não foi possível criar a peça.'});}};
