// Distributed locally with the SIL Open Font License beside each font file.
export const fontFamilies = ['Lobster','Pacifico','LilitaOne','Bangers','BebasNeue','BlackOpsOne','Caveat','Cinzel','Comfortaa','DancingScript','Fredoka','GreatVibes','AbrilFatface','Oswald','Rubik','PlayfairDisplay','Righteous','Sacramento'];
export function fontLabel(name){return name.replace(/([a-z])([A-Z])/g,'$1 $2');}
