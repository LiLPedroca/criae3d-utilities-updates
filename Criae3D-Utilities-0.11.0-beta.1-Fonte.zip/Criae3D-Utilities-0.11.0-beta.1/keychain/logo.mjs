import tracer from '../ui/vendor/imagetracer.js';
import {flatPath} from './geometry.mjs';
import {scope,measure,color,joinIslands,attachEyelet,meshOf,finishModel} from './modeling.mjs';
export const logoDefaults={width:50,border:2.4,base:2.4,raise:1.2,hole:4,ring:2,baseColor:'#243449',textColor:'#4169e1',colors:'image',maxColors:6,finish:'raised',faces:'front',nfc:false,nfcDiameter:25,nfcDepth:.8,nfcX:0,nfcY:0};
const rgbHex=c=>'#'+c.map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');
export function traceLogo(image,count,monochrome=false){
 const {width,height,data}=image||{};if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width*height>262144||data?.length!==width*height*4)throw Error('Imagem inválida (máximo 512 × 512 pixels processados).');
 if(!Number.isInteger(count)||count<2||count>8)throw Error('Use de 2 a 8 cores.');
 const hist=new Map();for(let i=0;i<data.length;i+=4)if(data[i+3]>=128){const c=[0,1,2].map(k=>Math.min(255,Math.round(data[i+k]/32)*32)),key=c.join(',');hist.set(key,(hist.get(key)||0)+1);}
 if(!hist.size)throw Error('A arte está vazia.');const ranked=[...hist].sort((a,b)=>b[1]-a[1]),colors=[];
 for(const [key]of ranked){const c=key.split(',').map(Number);if(!colors.length||colors.every(v=>Math.hypot(...c.map((p,i)=>p-v[i]))>55))colors.push(c);if(colors.length>=count)break;}
 const palette=[{r:0,g:0,b:0,a:0},...(monochrome?[[20,20,20]]:colors).map(c=>({r:c[0],g:c[1],b:c[2],a:255}))];
 const reduced=new Uint8ClampedArray(data.length);for(let i=0;i<data.length;i+=4){if(data[i+3]<128)continue;let best=0,dist=Infinity;if(!monochrome)colors.forEach((c,k)=>{const d=c.reduce((s,v,j)=>s+(v-data[i+j])**2,0);if(d<dist){dist=d;best=k;}});const c=monochrome?[20,20,20]:colors[best];reduced.set([...c,255],i);}
 const traced=tracer.imagedataToTracedata({width,height,data:reduced},{pal:palette,colorsampling:0,colorquantcycles:1,ltres:.3,qtres:.3,pathomit:2,rightangleenhance:false,roundcoords:6});
 const layers=[];for(let i=1;i<traced.layers.length;i++){
  const loops=[];const convert=path=>{if(!path?.segments?.length)return [];const first=path.segments[0],commands=[{type:'M',x:first.x1,y:first.y1}];for(const s of path.segments)commands.push(s.type==='L'?{type:'L',x:s.x2,y:s.y2}:{type:'Q',x1:s.x2,y1:s.y2,x:s.x3,y:s.y3});commands.push({type:'Z'});return flatPath(commands,.15);};
  for(const p of traced.layers[i])if(!p.isholepath){loops.push(...convert(p));for(const hole of p.holechildren)loops.push(...convert(traced.layers[i][hole]));}
  if(loops.length)layers.push({loops,color:rgbHex([palette[i].r,palette[i].g,palette[i].b])});
 }
 if(!layers.length)throw Error('Nenhum contorno útil. Use uma arte maior e com bordas nítidas.');return layers;
}
export function generateLogo(M,image,input={}){const o={...logoDefaults,...input};
 for(const [k,min,max]of [['width',20,200],['border',1.2,8],['base',1.2,10],['raise',.4,5],['hole',3,8],['ring',1.6,5],['nfcDiameter',10,40],['nfcDepth',.4,3],['nfcX',-150,150],['nfcY',-150,150]])measure(o[k],min,max,k);
 if(o.eyelet!==undefined)measure(o.eyelet,0,1,'Posição da argola');if(!['image','two'].includes(o.colors)||!['raised','flush'].includes(o.finish)||!['front','both'].includes(o.faces)||typeof o.nfc!=='boolean')throw Error('Opções da logo inválidas.');color(o.baseColor);color(o.textColor);
 const traced=traceLogo(image,o.maxColors,o.colors==='two');
 return scope(M,ctx=>{const {C,keep}=ctx;const points=traced.flatMap(l=>l.loops.flat()),minX=Math.min(...points.map(p=>p[0])),maxX=Math.max(...points.map(p=>p[0])),minY=Math.min(...points.map(p=>p[1]));const scale=o.width/(maxX-minX);
 const shapes=traced.map(l=>({shape:keep(new C(l.loops.map(loop=>loop.map(([x,y])=>[(x-minX)*scale,(y-minY)*scale])),'EvenOdd')),color:o.colors==='two'?o.textColor:l.color})).filter(p=>p.shape.area()>.02);
 if(!shapes.length)throw Error('A arte não possui área suficiente.');let art=shapes[0].shape;for(const part of shapes.slice(1))art=keep(art.add(part.shape));
 let supported=art;if(o.faces==='both')supported=keep(art.add(keep(art.mirror([1,0]).translate([o.width,0]))));
 let base=joinIslands(ctx,keep(supported.offset(o.border,'Round',2,64)),Math.max(1.6,o.border));const ring=attachEyelet(ctx,base,supported,o);base=ring.base;let body=keep(base.extrude(o.base));const warnings=['Cores da imagem são aproximadas em até '+o.maxColors+' tons. Confira os slots no fatiador.'];
 const totalZ=o.finish==='raised'?o.base+o.raise:o.base;
 const frontStart=o.finish==='raised'?o.base:o.base-o.raise;
 if(frontStart<.8||(o.faces==='both'&&o.finish==='flush'&&o.base-2*o.raise<.8))throw Error('Mantenha pelo menos 0,8 mm de núcleo entre as faces.');
 if(o.finish==='flush')body=keep(body.subtract(keep(keep(art.extrude(o.raise+.01)).translate([0,0,frontStart]))));
 if(o.faces==='both'){
   const back=keep(art.mirror([1,0]).translate([o.width,0]));
   if(keep(back.subtract(base)).area()>.01)throw Error('O verso espelhado sai da base. Use só frente ou uma arte simétrica.');
   if(o.finish==='flush')body=keep(body.subtract(keep(back.extrude(o.raise))));
 }
 let nfc;
 if(o.nfc){
  if(o.faces==='both')throw Error('O alojamento NFC aberto no verso exige somente frente.');
  const bounds=base.bounds(),center=[(bounds.min[0]+bounds.max[0])/2+o.nfcX,(bounds.min[1]+bounds.max[1])/2+o.nfcY];const pocket=keep(C.circle(o.nfcDiameter/2,96).translate(center)),safe=keep(base.offset(-1.6,'Round',2,64));
  if(keep(pocket.subtract(safe)).area()>.001||Math.hypot(center[0]-ring.eyelet.center[0],center[1]-ring.eyelet.center[1])<o.nfcDiameter/2+ring.eyelet.radius+1.6)throw Error('NFC: mantenha 1,6 mm da borda e da argola. Aumente a peça ou reposicione o alojamento.');
  if(frontStart-o.nfcDepth<1.2)throw Error('NFC: mantenha 1,2 mm de material acima do alojamento.');
  body=keep(body.subtract(keep(pocket.extrude(o.nfcDepth))));nfc={center,radius:o.nfcDiameter/2};warnings.push('Alojamento NFC aberto no verso. Tag e fechamento não inclusos; confira as dimensões físicas.');
 }
 const meshes=[meshOf(body,'Base e argola',o.baseColor,1)];for(const [i,p]of shapes.entries()){
  let solid=keep(keep(p.shape.extrude(o.raise)).translate([0,0,frontStart]));
  if(o.faces==='both'){const back=keep(p.shape.mirror([1,0]).translate([o.width,0]));solid=keep(solid.add(keep(keep(back.extrude(o.raise)).translate([0,0,o.finish==='raised'?-o.raise:0]))));}
  if(o.faces==='both'&&o.finish==='raised'){solid=keep(solid.translate([0,0,o.raise]));}
  meshes.push(meshOf(solid,'Arte '+(i+1),p.color,i+2));
 }
 if(o.faces==='both'&&o.finish==='raised'){meshes[0].vertices=meshes[0].vertices.map((v,i)=>i%3===2?v+o.raise:v);}
 return finishModel({...o,base:totalZ},meshes,[{loops:base.toPolygons(),color:o.baseColor},...shapes.map(p=>({loops:p.shape.toPolygons(),color:p.color}))],{...ring,base:undefined,nfc,artBounds:{min:[minX,minY],scale},sourceDimensions:[image.width,image.height]},warnings);
 });}
