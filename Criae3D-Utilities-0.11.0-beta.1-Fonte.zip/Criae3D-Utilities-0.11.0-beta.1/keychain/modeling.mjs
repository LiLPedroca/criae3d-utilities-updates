import {flatPath, fontPath, signedArea, pointOnLoop, nearestOnLoop} from './geometry.mjs';
export function scope(M, work) {
  const owned=[];const keep=x=>(owned.push(x),x);
  try{return work({M,C:M.CrossSection,keep});}finally{for(let i=owned.length-1;i>=0;i--)owned[i].delete();}
}
export function measure(value,min,max,label){if(!Number.isFinite(value)||value<min||value>max)throw Error(label+': use de '+min+' a '+max+' mm.');return value;}
export function color(value){if(!/^#[a-f\d]{6}$/i.test(value))throw Error('Cor inválida.');return value;}
export function textShape(ctx,font,text,height) {
  text=String(text).normalize('NFC').trim();if(!text||text.length>40||/[\x00-\x1f]/.test(text))throw Error('Texto: use de 1 a 40 caracteres.');
  for(const ch of text)if(ch!==' '&&!font.charToGlyphIndex(ch))throw Error('A fonte não possui o caractere “'+ch+'”.');
  const path=fontPath(font,text),bb=path.getBoundingBox(),scale=height/(bb.y2-bb.y1);
  if(!Number.isFinite(scale)||bb.x2<=bb.x1)throw Error('Texto sem contornos.');
  return ctx.keep(new ctx.C(flatPath(path.commands,.02/scale).map(loop=>loop.map(([x,y])=>[(x-bb.x1)*scale,(y+bb.y2)*scale])),'NonZero'));
}
export function joinIslands(ctx,shape,width) {
  const {C,keep}=ctx;
  for(let pass=0;pass<60;pass++) {
    const parts=shape.decompose().map(keep);if(parts.length===1)return shape;if(parts.length>100)throw Error('Há muitas partes soltas. Simplifique a arte.');
    if(parts.length===0)throw Error('Nenhum contorno encontrado.');
    const loops=parts.map(p=>p.toPolygons().flat().filter((_,i,a)=>i%Math.max(1,Math.ceil(a.length/120))===0));let best;
    for(let i=1;i<loops.length;i++)for(const a of loops[0])for(const b of loops[i]){const d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(!best||d<best.d)best={a,b,d};}
    shape=keep(shape.add(keep(C.hull([keep(C.circle(width/2,24).translate(best.a)),keep(C.circle(width/2,24).translate(best.b))]))));
  }
  throw Error('Não foi possível ligar as partes. Aproxime as letras ou simplifique a arte.');
}
export function attachEyelet(ctx,base,art,o){const {C,keep}=ctx;
  const outer=base.toPolygons().sort((a,b)=>Math.abs(signedArea(b))-Math.abs(signedArea(a)))[0];if(signedArea(outer)<0)outer.reverse();
  const t=o.eyelet??nearestOnLoop(outer,[(base.bounds().min[0]+base.bounds().max[0])/2,10000]).t;
  const anchor=pointOnLoop(outer,t),radius=o.hole/2+o.ring,center=anchor.point.map((p,i)=>p+anchor.normal[i]*(radius-Math.min(2,o.ring)));
  const disc=keep(C.circle(radius,80).translate(center)),hole=keep(C.circle(o.hole/2,64).translate(center));
  if(keep(art.intersect(hole)).area()>.001)throw Error('A argola corta a arte. Reposicione-a.');
  base=keep(keep(base.add(disc)).subtract(hole));
  if(base.decompose().map(keep).length!==1||keep(art.subtract(base)).area()>.01)throw Error('A arte e a argola precisam ficar apoiadas na base.');
  return {base,perimeter:outer,eyelet:{center,radius,hole:o.hole/2,anchor:anchor.point}};
}
export function meshOf(solid,name,paint,slot){if(solid.status()!=='NoError'||solid.volume()<=0)throw Error('Geometria inválida: '+name);const m=solid.getMesh(),vertices=[];for(let i=0;i<m.vertProperties.length;i+=m.numProp)vertices.push(...m.vertProperties.slice(i,i+3));return {name,color:color(paint),slot,vertices,triangles:Array.from(m.triVerts)};}
export function finishModel(options,meshes,layers,extra={},warnings=[]){const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(const m of meshes)for(let i=0;i<m.vertices.length;i++){min[i%3]=Math.min(min[i%3],m.vertices[i]);max[i%3]=Math.max(max[i%3],m.vertices[i]);}if(max.some((p,i)=>p-min[i]>400))throw Error('A composição excede 400 mm. Reduza os textos.');return {options,meshes,layers,bounds:{min:min.slice(0,2),max:max.slice(0,2)},dimensions:max.map((p,i)=>p-min[i]),warnings,...extra};}
