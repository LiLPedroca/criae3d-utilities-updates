import {scope,measure,color,textShape,joinIslands,meshOf,finishModel} from './modeling.mjs';
export const wordDefaults={word:'AMOR',phrase:'Família',font:'Cinzel',secondFont:'Pacifico',height:50,secondHeight:24,depth:10,secondDepth:3,link:2,x:0,y:0,baseColor:'#168bd2',textColor:'#fff4dc',fit:false,tolerance:.3,pegDepth:2.4};
export function generateWords(M,fonts,input={}){const o={...wordDefaults,...input};
 for(const [k,min,max]of [['height',10,120],['secondHeight',5,80],['depth',2,25],['secondDepth',1.2,12],['link',1.2,6],['tolerance',.1,.6],['pegDepth',1,5],['x',-150,150],['y',-100,100]])measure(o[k],min,max,k);
 color(o.baseColor);color(o.textColor);if(typeof o.fit!=='boolean')throw Error('Encaixe inválido.');
 return scope(M,ctx=>{const {C,keep}=ctx;let base=joinIslands(ctx,textShape(ctx,fonts[0],o.word,o.height),o.link);let phrase=joinIslands(ctx,textShape(ctx,fonts[1],o.phrase,o.secondHeight),Math.max(1.2,o.link*.6));
 const b=base.bounds(),p=phrase.bounds();phrase=keep(phrase.translate([(b.max[0]-p.max[0])/2+o.x,(o.height-o.secondHeight)/2+o.y]));
 if(keep(phrase.intersect(base)).area()<1)throw Error('Posicione a segunda frase sobre a palavra base.');
 const parts=phrase.decompose().map(keep);for(const part of parts)if(keep(part.intersect(base)).area()<.3)throw Error('Há uma parte da frase sem apoio. Aproxime os textos ou escolha outra fonte.');
 let body=keep(base.extrude(o.depth)),top=keep(phrase.extrude(o.secondDepth));const warnings=['Confira a estabilidade e os detalhes finos no fatiador. Não houve impressão física de validação.'];
 if(o.fit){
  if(o.depth<o.pegDepth+1.2)throw Error('A base precisa manter pelo menos 1,2 mm abaixo dos encaixes.');
  let pegs;
  for(const part of parts){const support=keep(keep(part.intersect(base)).offset(-Math.max(.8,o.tolerance+.5),'Round',2,32));if(support.isEmpty())throw Error('Texto fino demais para encaixe. Aumente a altura ou use sem encaixe.');pegs=pegs?keep(pegs.add(support)):support;}
  const sockets=keep(pegs.offset(o.tolerance,'Round',2,32));if(keep(sockets.subtract(base)).area()>.001)throw Error('Encaixe muito próximo da borda.');
  body=keep(body.subtract(keep(keep(sockets.extrude(o.pegDepth+.01)).translate([0,0,o.depth-o.pegDepth]))));
  top=keep(top.add(keep(keep(pegs.extrude(o.pegDepth)).translate([0,0,-o.pegDepth]))));
  // Export the two printable pieces side by side, with their lowest points on the bed.
  const shift=b.max[0]+10-p.min[0];top=keep(top.translate([shift,0,o.pegDepth]));
  warnings.push('Encaixe experimental: peças exportadas lado a lado. Imprima uma amostra para conferir a folga de '+o.tolerance+' mm.');
 }else top=keep(top.translate([0,0,o.depth]));
 const meshes=[meshOf(body,'Palavra base',o.baseColor,1),meshOf(top,'Segunda frase',o.textColor,2)];
 return finishModel({...o,base:o.depth},meshes,[{loops:base.toPolygons(),color:o.baseColor},{loops:phrase.toPolygons(),color:o.textColor}],{wordBounds:b,previewBounds:b,previewDimensions:[b.max[0]-b.min[0],b.max[1]-b.min[1],o.depth+o.secondDepth]},warnings);
 });}
