import factory from 'manifold-3d';
import opentype from 'opentype.js';
import {fontFamilies} from './fonts.mjs';
import {generateLogo} from './logo.mjs';
import {generateWords} from './words.mjs';
const ready=factory({locateFile:()=>new URL('manifold.wasm',self.location.href).href}).then(M=>{M.setup();return M;});
const fonts=new Map();
async function font(name){if(!fontFamilies.includes(name))throw Error('Fonte inválida.');if(!fonts.has(name)){const r=await fetch(new URL('../assets/fonts/'+name+'-Regular.ttf',self.location.href));if(!r.ok)throw Error('Não foi possível carregar a fonte.');fonts.set(name,opentype.parse(await r.arrayBuffer()));}return fonts.get(name);}
self.onmessage=async({data})=>{try{const M=await ready;let result;if(data.kind==='logo')result=generateLogo(M,data.image,data.options);else if(data.kind==='words')result=generateWords(M,await Promise.all([font(data.options.font),font(data.options.secondFont)]),data.options);else throw Error('Modelo inválido.');self.postMessage({id:data.id,ok:true,result});}catch(e){self.postMessage({id:data.id,ok:false,message:e.message||'Não foi possível gerar a peça.'});}};
