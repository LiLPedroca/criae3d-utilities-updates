'use strict';
const {zipSync,strToU8}=require('fflate');
const xml=s=>String(s).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));
// IPC accepts geometry, never arbitrary ZIP entries, paths or executable arguments.
function validate(model){if(!model||!Array.isArray(model.meshes)||model.meshes.length<2||model.meshes.length>16)throw Error('Peça inválida.');
 let totalVertices=0,totalTriangles=0;
 const totalBounds={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};
 for(const mesh of model.meshes){const {vertices:v,triangles:t,color}=mesh;if(mesh.slot!==undefined&&(!Number.isInteger(mesh.slot)||mesh.slot<1||mesh.slot>16))throw Error('Slot inválido (1 a 16).');if(!Array.isArray(v)||!Array.isArray(t)||v.length<12||v.length>900000||t.length<12||t.length>1800000||v.length%3||t.length%3||!/^#[a-f\d]{6}$/i.test(color))throw Error('Malha inválida.');
 totalVertices+=v.length;totalTriangles+=t.length;if(totalVertices>1800000||totalTriangles>3600000)throw Error('Modelo muito complexo.');
 for(let i=0;i<v.length;i++){if(!Number.isFinite(v[i])||Math.abs(v[i])>500)throw Error('Coordenada inválida.');totalBounds.min[i%3]=Math.min(totalBounds.min[i%3],v[i]);totalBounds.max[i%3]=Math.max(totalBounds.max[i%3],v[i]);}
 const edges=new Map();let volume=0;
 for(let i=0;i<t.length;i+=3){const ids=t.slice(i,i+3);if(ids.some(k=>!Number.isInteger(k)||k<0||k>=v.length/3)||new Set(ids).size!==3)throw Error('Índice inválido.');for(let k=0;k<3;k++){const a=ids[k],b=ids[(k+1)%3],key=Math.min(a,b)+','+Math.max(a,b),edge=edges.get(key)||[0,0];edge[0]++;edge[1]+=a<b?1:-1;edges.set(key,edge);}const [a,b,c]=ids.map(k=>v.slice(k*3,k*3+3));volume+=(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6;}
 if(volume<=0||[...edges.values()].some(e=>e[0]!==2||e[1]!==0))throw Error('A malha precisa ser fechada e orientada.');
 }return totalBounds;
}
function create3mf(model){validate(model);const name=String(model.name||'Chaveiro').slice(0,80),resources=model.meshes.map((mesh,i)=>{
 let vertices='';for(let k=0;k<mesh.vertices.length;k+=3)vertices+='<vertex x="'+mesh.vertices[k]+'" y="'+mesh.vertices[k+1]+'" z="'+mesh.vertices[k+2]+'"/>';
 let triangles='';for(let k=0;k<mesh.triangles.length;k+=3)triangles+='<triangle v1="'+mesh.triangles[k]+'" v2="'+mesh.triangles[k+1]+'" v3="'+mesh.triangles[k+2]+'"/>';
 return '<basematerials id="'+(i+100)+'"><base name="'+xml(mesh.name||(i?'Texto':'Base'))+'" displaycolor="'+mesh.color.toUpperCase()+'FF'+'"/></basematerials><object id="'+(i+1)+'" name="'+xml(mesh.name||(i?'Texto':'Base e argola'))+'" type="model" pid="'+(i+100)+'" pindex="0"><mesh><vertices>'+vertices+'</vertices><triangles>'+triangles+'</triangles></mesh></object>';
 }).join('');
 const modelXml='<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="pt-BR" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><metadata name="Title">'+xml(name)+'</metadata><metadata name="Application">Criae3D Utilities</metadata><resources>'+resources+'<object id="1000" type="model" name="'+xml(name)+'"><components>'+model.meshes.map((_,i)=>'<component objectid="'+(i+1)+'"/>').join('')+'</components></object></resources><build><item objectid="1000"/></build></model>';
 const config='<?xml version="1.0" encoding="UTF-8"?><config><object id="1000"><metadata key="name" value="'+xml(name)+'"/>'+model.meshes.map((mesh,i)=>'<part id="'+(i+1)+'" subtype="normal_part"><metadata key="name" value="'+xml(mesh.name||(i?'Texto':'Base e argola'))+'"/><metadata key="extruder" value="'+(mesh.slot||i+1)+'"/></part>').join('')+'</object></config>';
 return Buffer.from(zipSync({'[Content_Types].xml':strToU8('<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/><Default Extension="config" ContentType="application/xml"/></Types>'),'_rels/.rels':strToU8('<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'),'3D/3dmodel.model':strToU8(modelXml),'Metadata/model_settings.config':strToU8(config)},{level:6}));
}
module.exports={create3mf,validate};
