'use strict';
const {app,BrowserWindow,ipcMain,dialog,shell,safeStorage}=require('electron');
const fs=require('node:fs/promises'),path=require('node:path');
const {Store}=require('./store.cjs');
let store,window;
const storage=require('./storage.cjs');
let exportFolders;
const {Updates}=require('./updater.cjs');
let updates;
if(!app.isPackaged&&process.env.CRIAE3D_TEST_DATA){require('node:fs').mkdirSync(process.env.CRIAE3D_TEST_DATA,{recursive:true});app.setPath('userData',process.env.CRIAE3D_TEST_DATA);}
if(!app.requestSingleInstanceLock())app.quit();
app.on('second-instance',()=>{if(window){window.restore();window.focus();}});
app.whenReady().then(()=>{
 app.setAppUserModelId('br.com.criae3d.utilities');
 store=new Store(path.join(app.getPath('userData'),'Dados'));
 exportFolders=storage.folders(store.read().settings.exportRoot||path.join(process.env.CRIAE3D_TEST_DATA||app.getPath('documents'),'Criae3D Utilities'));
 const versionFile=path.join(store.directory,'versao.txt'),syncFs=require('node:fs');
 const lastVersion=syncFs.existsSync(versionFile)?syncFs.readFileSync(versionFile,'utf8'):'';
 if(lastVersion!==app.getVersion()){if(syncFs.existsSync(store.file))store.backup();syncFs.writeFileSync(versionFile,app.getVersion());}
 storage.snapshot(exportFolders.clients,store.read(),exportFolders.products);
 const handle=(name,callback)=>ipcMain.handle(name,async(event,...args)=>{if(event.sender!==window.webContents||event.senderFrame!==window.webContents.mainFrame)throw Error('Acesso não permitido.');return callback(...args);});
 updates=new Updates(require('electron-updater').autoUpdater,app.isPackaged,state=>{if(window&&!window.isDestroyed())window.webContents.send('update:state',state);});
 const {Auth}=require('./auth.cjs');
 const auth=new Auth({directory:app.getPath('userData'),safeStorage,config:require('./auth-config.cjs')});
 handle('account:action',async(action,values)=>{try{return {ok:true,value:await auth.run(action,values)};}catch(error){return {ok:false,message:error.message};}});
 handle('update:state',()=>updates.read());
 handle('update:check',()=>updates.check());
 handle('update:download',()=>updates.download());
 handle('update:install',async()=>{if(updates.read().phase!=='downloaded')throw Error('Atualização ainda não está pronta.');store.backup();setImmediate(()=>updates.install());return true;});
 handle('data:read',()=>store.read());handle('data:save',data=>{const result=store.write(data);storage.snapshot(exportFolders.clients,result,exportFolders.products);return result;});
 handle('app:info',()=>({version:app.getVersion(),folders:exportFolders,...store.usage()}));
 handle('folder:open',key=>{if(!Object.hasOwn(exportFolders,key))throw Error('Pasta inválida.');return shell.openPath(exportFolders[key]);});
 handle('folder:choose',async()=>{const result=await dialog.showOpenDialog(window,{title:'Escolha a pasta principal dos arquivos',properties:['openDirectory','createDirectory']});if(result.canceled)return null;const data=store.read();data.settings.exportRoot=result.filePaths[0];const next=storage.folders(data.settings.exportRoot);store.write(data);exportFolders=next;storage.snapshot(exportFolders.clients,data,exportFolders.products);return data;});
 handle('data:open',()=>shell.openPath(store.directory));
 handle('backup:export',async()=>{const {canceled,filePath}=await dialog.showSaveDialog(window,{defaultPath:path.join(exportFolders.backups,storage.backupName()),filters:[{name:'Backup JSON',extensions:['json']}]});if(canceled)return false;await fs.writeFile(filePath,JSON.stringify(store.read(),null,2));return true;});
 handle('backup:restore',async()=>{const selected=await dialog.showOpenDialog(window,{filters:[{name:'Backup JSON',extensions:['json']}],properties:['openFile']});if(selected.canceled)return null;const stat=await fs.stat(selected.filePaths[0]);if(stat.size>20*1024*1024)throw Error('Backup excede 20 MB.');const data=JSON.parse(await fs.readFile(selected.filePaths[0],'utf8'));require('./store.cjs').validate(data);const answer=await dialog.showMessageBox(window,{type:'warning',buttons:['Cancelar','Restaurar'],defaultId:0,cancelId:0,message:'Substituir os cadastros atuais por este backup?',detail:'Uma cópia dos dados atuais será criada automaticamente antes da restauração.'});if(answer.response!==1)return null;delete data.settings.exportRoot;const result=store.restore(data);exportFolders=storage.folders(path.join(process.env.CRIAE3D_TEST_DATA||app.getPath('documents'),'Criae3D Utilities'));storage.snapshot(exportFolders.clients,result.data,exportFolders.products);return result;});
 const {Slicers,catalog:slicerCatalog}=require('./slicers.cjs');
 const slicers=new Slicers(app.getPath('userData'));
 handle('slicer:state',()=>slicers.state());
 handle('slicer:detect',()=>slicers.detect());
 handle('slicer:save',(keys,active)=>slicers.save(keys,active));
 handle('slicer:activate',id=>slicers.activate(id));
 handle('slicer:open',id=>slicers.open(id));
 handle('slicer:policy',id=>slicers.policy(id));
 handle('slicer:send',(id,svg)=>slicers.send(id,svg));
 handle('slicer:manual',async id=>{if(!slicerCatalog.some(c=>c.id===id))throw Error('Fatiador inválido.');const result=await dialog.showOpenDialog(window,{title:'Localizar '+slicerCatalog.find(c=>c.id===id).name,properties:['openFile'],filters:[{name:'Executável do fatiador',extensions:['exe']}]});if(result.canceled)return null;return slicers.merge(slicers.candidate(id,result.filePaths[0]).key);});
 handle('keychain:policy',id=>slicers.policy(id,'3MF'));
 handle('keychain:send',(id,model)=>slicers.send3mf(id,model));
 handle('keychain:save',async model=>{const bytes=require('./keychain-3mf.cjs').create3mf(model),name=String(model.name||'Chaveiro').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').slice(0,80)+'.3mf';const {canceled,filePath}=await dialog.showSaveDialog(window,{defaultPath:path.join(exportFolders.products,name),filters:[{name:'3MF multicor',extensions:['3mf']}]});if(canceled)return false;await fs.writeFile(filePath,bytes);return true;});
 handle('svg:save',async(name,svg)=>{if(typeof name!=='string'||typeof svg!=='string'||svg.length>10*1024*1024||!svg.startsWith('<svg ')||/<(?:script|image|foreignObject)\b|\bon\w+\s*=|(?:href|url)\s*[:=(]/i.test(svg))throw Error('SVG inválido.');const clean=path.basename(name).replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/\.svg$/i,'')+'.svg';const {canceled,filePath}=await dialog.showSaveDialog(window,{defaultPath:path.join(exportFolders.products,clean),filters:[{name:'SVG',extensions:['svg']}]});if(canceled)return false;await fs.writeFile(filePath,svg,'utf8');return true;});
 handle('pdf:save',async(name,bytes)=>{if(typeof name!=='string'||!Array.isArray(bytes)||bytes.length>20*1024*1024)throw Error('PDF inválido.');const clean=path.basename(name).replace(/[<>:"/\\|?*\x00-\x1f]/g,'_');const {canceled,filePath}=await dialog.showSaveDialog(window,{defaultPath:path.join(exportFolders.quotes,clean),filters:[{name:'PDF',extensions:['pdf']}]});if(canceled)return false;await fs.writeFile(filePath,Buffer.from(bytes));return true;});
 window=new BrowserWindow({show:!process.env.CRIAE3D_TEST_DATA,icon:path.join(__dirname,'ui/assets/app-icon.png'),width:1220,height:820,minWidth:800,minHeight:600,backgroundColor:'#ffffff',title:'Criae3D Utilities',webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true}});
 let discardClose=false,closePrompt=false;
 require('electron').autoUpdater.once('before-quit-for-update',()=>{discardClose=true;});
 window.on('close',event=>{if(discardClose)return;event.preventDefault();if(closePrompt)return;closePrompt=true;window.webContents.send('window:close-requested');});
 window.webContents.on('will-prevent-unload',event=>{
  if(discardClose){event.preventDefault();return;}
  if(closePrompt)return;
  closePrompt=true;
  window.webContents.send('window:close-requested');
 });
 handle('window:close-choice',action=>{
  if(!closePrompt)return false;
  if(action==='cancel'){closePrompt=false;return true;}
  if(!['discard','clean'].includes(action))throw Error('Opção de fechamento inválida.');
  // Keep the last committed data recoverable before allowing the pending form to be discarded.
  if(action==='discard')store.backup();discardClose=true;setImmediate(()=>{if(!window.isDestroyed())window.close();});return true;
 });
 window.webContents.setWindowOpenHandler(()=>({action:'deny'}));window.webContents.on('will-navigate',event=>event.preventDefault());window.removeMenu();window.loadFile('ui/index.html');
});
app.on('window-all-closed',()=>app.quit());
