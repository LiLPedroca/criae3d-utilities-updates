'use strict';
// Real Electron/main/preload, isolated data, native save dialogs replaced only at the boundary.
const {_electron}=require(process.env.CRIAE3D_PLAYWRIGHT||'playwright');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {unzipSync,strFromU8}=require('fflate');
const root=path.join(__dirname,'..'),artifacts=path.join(__dirname,'artifacts');
fs.mkdirSync(artifacts,{recursive:true});
(async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'criae-studio-'));
 const originalClient={id:'old',name:'Cliente preservado',phone:'11999999999'};
 fs.mkdirSync(path.join(profile,'Dados'));
 fs.writeFileSync(path.join(profile,'Dados/dados.json'),JSON.stringify({format:'criae3d-utilities',schema:1,settings:{company:{name:'Empresa preservada'},theme:'dark',accent:'blue',colors:{},profile:{name:'Pedro'},seenRelease:require('../package.json').version,appearanceReady:true,reduceMotion:true,calculatorIntroDismissed:true},clients:[originalClient],products:[],quotes:[],draft:null}));
 const app=await _electron.launch({executablePath:process.env.CRIAE3D_ELECTRON||require('electron'),args:[process.env.CRIAE3D_TEST_APP||root,'--disable-webgl'],env:{...process.env,CRIAE3D_TEST_DATA:profile},timeout:30000});
 try {
  const p=await app.firstWindow();p.setDefaultTimeout(30000);const errors=[];p.on('pageerror',e=>errors.push(e.message));
  await app.evaluate(({BrowserWindow})=>{BrowserWindow.getAllWindows()[0].setSize(1440,1000);BrowserWindow.getAllWindows()[0].showInactive();});
  await p.locator('.studio-category').first().waitFor();
  assert.deepEqual(await p.locator('.category-copy strong').allTextContents(),['Gestão financeira','Ferramentas','Modelos personalizados']);
  await p.screenshot({path:path.join(artifacts,'studio-home.png')});
  const accent=await p.evaluate(()=>database.settings.accent);
  await p.click('#studioTheme');assert.equal(await p.evaluate(()=>database.settings.theme),'light');assert.equal(await p.evaluate(()=>database.settings.accent),accent);await p.click('#studioTheme');
  await p.fill('#toolSearch','chaveiro');assert.equal(await p.locator('#studioResults .clean-tool').count(),2);await p.fill('#toolSearch','');
  // Enter via the new category and its card rather than an internal route shortcut.
  await p.click('.studio-category[data-route=models]');await p.click('#screen [data-route=keychain]');await p.locator('#kcExport:enabled').waitFor();
  assert.equal(await p.inputValue('#kcName'),'Personalize');assert.equal(await p.locator('#kcFont option').count(),18);
  await p.fill('#kcWidth','60');await p.locator('#kcExport:enabled').waitFor();assert(Math.abs(await p.evaluate(()=>keychain.result.dimensions[0])-60)<.002);
  await p.selectOption('#kcUnit','cm');assert.equal(await p.inputValue('#kcWidth'),'6');await p.fill('#kcWidth','8');await p.locator('#kcExport:enabled').waitFor();assert(Math.abs(await p.evaluate(()=>keychain.result.dimensions[0])-80)<.002);
  assert.equal(await p.evaluate(()=>keychain.viewer.mode),'2d');
  await p.locator('.kc-filaments summary').click();await p.selectOption('#kcTextSlot','5');
  const keyFile=path.join(profile,'keychain.3mf');await app.evaluate(({dialog},file)=>{dialog.showSaveDialog=async()=>({canceled:false,filePath:file});},keyFile);
  await p.click('#kcExport');await p.waitForFunction(()=>!keychain.exporting);assert(fs.existsSync(keyFile));
  const keyZip=unzipSync(fs.readFileSync(keyFile));assert.match(strFromU8(keyZip['Metadata/model_settings.config']),/extruder" value="5/);
  const xml=strFromU8(keyZip['3D/3dmodel.model']),xs=[...xml.matchAll(/<vertex x="([^"]+)"/g)].map(m=>Number(m[1]));assert(Math.abs(Math.max(...xs)-Math.min(...xs)-80)<.002);
  await p.evaluate(()=>navigate('words'));await p.waitForFunction(()=>creator.result||(!creator.running&&!creator.pending));assert(await p.evaluate(()=>!!creator.result));
  await p.click('#creatorHeight');assert(await p.locator('#creatorHeightPanel').isVisible());
  await p.screenshot({path:path.join(artifacts,'studio-words.png')});
  await app.evaluate(({dialog})=>{dialog.showSaveDialog=async()=>({canceled:true});});
  await p.locator('[data-option=phrase]').fill('Família');await p.waitForFunction(()=>creator.result&&!creator.running&&!creator.pending);await p.click('#creatorExport');await p.waitForFunction(()=>!creator.exporting);assert(await p.evaluate(()=>creator.dirty),'Cancelar não descarta a peça');
  const wordFile=path.join(profile,'words.3mf');await app.evaluate(({dialog},file)=>{dialog.showSaveDialog=async()=>({canceled:false,filePath:file});},wordFile);await p.click('#creatorExport');await p.waitForFunction(()=>!creator.exporting);assert(fs.existsSync(wordFile));
  await p.evaluate(()=>navigate('logo'));
  const png=await p.evaluate(()=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.fillStyle='#ef4444';x.fillRect(8,8,24,48);x.fillStyle='#4169e1';x.fillRect(32,8,24,48);return c.toDataURL().split(',')[1];});
  await p.locator('#creatorFile').setInputFiles({name:'logo.png',mimeType:'image/png',buffer:Buffer.from(png,'base64')});
  await p.waitForFunction(()=>creator.image&&creator.result&&!creator.running&&!creator.pending);assert.equal(await p.evaluate(()=>creator.result.meshes.length),3);
  await p.screenshot({path:path.join(artifacts,'studio-logo.png')});
  await p.locator('summary').filter({hasText:'Tag NFC'}).click();await p.locator('[data-option=nfc]').check();await p.waitForFunction(()=>!creator.running&&!creator.pending);assert(await p.evaluate(()=>!!creator.result));
  await p.locator('[data-option=nfcX]').fill('100');await p.locator('[data-option=nfcX]').press('Tab');await p.waitForFunction(()=>!creator.running&&!creator.pending);assert(await p.locator('#creatorExport').isDisabled());assert.match(await p.textContent('#creatorStatus'),/NFC/);
  await p.locator('[data-option=nfcX]').fill('0');await p.locator('[data-option=nfcX]').press('Tab');await p.waitForFunction(()=>creator.result&&!creator.running&&!creator.pending);
  await p.click('#creatorUndo');await p.waitForFunction(()=>!creator.running&&!creator.pending);assert(await p.locator('#creatorExport').isDisabled());await p.click('#creatorRedo');await p.waitForFunction(()=>creator.result&&!creator.running&&!creator.pending);
  const logoFile=path.join(profile,'logo.3mf');await app.evaluate(({dialog},file)=>{dialog.showSaveDialog=async()=>({canceled:false,filePath:file});},logoFile);await p.click('#creatorExport');await p.waitForFunction(()=>!creator.exporting);assert(fs.existsSync(logoFile));assert.equal((strFromU8(unzipSync(fs.readFileSync(logoFile))['3D/3dmodel.model']).match(/<component /g)||[]).length,3);
  // Opening scenes are optional; reduction of motion takes precedence, including OS preference.
  await p.evaluate(()=>{database.settings.reduceMotion=false;database.settings.openingAnimations=true;applyTheme();navigate('home');navigate('clients');});await p.locator('#openingScene').waitFor();await p.keyboard.press('Escape');assert.equal(await p.locator('#openingScene').count(),0);
  await p.evaluate(()=>{database.settings.openingAnimations=false;navigate('home');navigate('clients');});assert.equal(await p.locator('#openingScene').count(),0);
  await p.emulateMedia({reducedMotion:'reduce'});await p.evaluate(()=>{database.settings.openingAnimations=true;navigate('home');navigate('clients');});assert.equal(await p.locator('#openingScene').count(),0);
  assert.deepEqual(await p.evaluate(()=>database.clients),[originalClient]);assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(artifacts,'studio-result.json'),JSON.stringify({ok:true,version:require('../package.json').version,errors,profile,checks:['categories','search','theme','18 fonts','total width mm/cm','real 3MF IPC','slots','words','logo','NFC guards','undo/redo','opening/motion','preserved clients']}));
  console.log('PASS studio: navigation, theme/search, total width mm/cm, 18 fonts, real 3MF saves, slots, words/logo, cancellation, NFC guards, undo/redo, motion preferences and data preservation.');
 } finally {await app.evaluate(({app})=>app.exit(0)).catch(()=>{});}
})().catch(e=>{console.error(e);process.exitCode=1;});
