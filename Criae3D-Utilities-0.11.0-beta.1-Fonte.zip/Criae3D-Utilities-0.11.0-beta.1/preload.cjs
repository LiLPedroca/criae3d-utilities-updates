'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('desktop',{
 slicers:{state:()=>ipcRenderer.invoke('slicer:state'),detect:()=>ipcRenderer.invoke('slicer:detect'),save:(keys,active)=>ipcRenderer.invoke('slicer:save',keys,active),activate:id=>ipcRenderer.invoke('slicer:activate',id),manual:id=>ipcRenderer.invoke('slicer:manual',id),open:id=>ipcRenderer.invoke('slicer:open',id),policy:id=>ipcRenderer.invoke('slicer:policy',id),send:(id,svg)=>ipcRenderer.invoke('slicer:send',id,svg)},
 keychain:{save:model=>ipcRenderer.invoke('keychain:save',model),policy:id=>ipcRenderer.invoke('keychain:policy',id),send:(id,model)=>ipcRenderer.invoke('keychain:send',id,model)},
 saveSvg:(name,svg)=>ipcRenderer.invoke('svg:save',name,svg),
 closeChoice:action=>ipcRenderer.invoke('window:close-choice',action),
 onCloseRequested:callback=>{const listener=()=>callback();ipcRenderer.on('window:close-requested',listener);return ()=>ipcRenderer.removeListener('window:close-requested',listener);},
 account:async(action,values)=>{const result=await ipcRenderer.invoke('account:action',action,values);if(!result.ok)throw Error(result.message);return result.value;},
 updateState:()=>ipcRenderer.invoke('update:state'),checkUpdates:()=>ipcRenderer.invoke('update:check'),downloadUpdate:()=>ipcRenderer.invoke('update:download'),installUpdate:()=>ipcRenderer.invoke('update:install'),onUpdate:callback=>{const listener=(_event,state)=>callback(state);ipcRenderer.on('update:state',listener);return ()=>ipcRenderer.removeListener('update:state',listener);},
 openFolder:key=>ipcRenderer.invoke('folder:open',key),chooseFolder:()=>ipcRenderer.invoke('folder:choose'),
 read:()=>ipcRenderer.invoke('data:read'),save:data=>ipcRenderer.invoke('data:save',data),info:()=>ipcRenderer.invoke('app:info'),openData:()=>ipcRenderer.invoke('data:open'),backup:()=>ipcRenderer.invoke('backup:export'),restore:()=>ipcRenderer.invoke('backup:restore'),savePdf:(name,bytes)=>ipcRenderer.invoke('pdf:save',name,Array.from(bytes))
});
