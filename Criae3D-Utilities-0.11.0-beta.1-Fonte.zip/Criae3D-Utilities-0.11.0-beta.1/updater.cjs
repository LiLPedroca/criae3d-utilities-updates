'use strict';
class Updates{
 constructor(updater,enabled,publish=()=>{}){this.updater=updater;this.enabled=enabled;this.publish=publish;this.state={phase:'idle',version:'',percent:0,message:'Confira novas versões quando quiser.'};updater.autoDownload=false;updater.autoInstallOnAppQuit=false;updater.allowDowngrade=false;updater.allowPrerelease=false;
 updater.on('checking-for-update',()=>this.set({phase:'checking',message:'Conferindo atualizações…'}));
 updater.on('update-available',info=>this.set({phase:'available',version:info.version,percent:0,message:'Versão '+info.version+' disponível.'}));
 updater.on('update-not-available',()=>this.set({phase:'current',message:'Você está usando a versão mais recente publicada.'}));
 updater.on('download-progress',p=>this.set({phase:'downloading',percent:Math.max(this.state.percent||0,Math.min(99.9,Number(p.percent)||0)),message:'Baixando atualização…'}));
 updater.on('update-downloaded',info=>this.set({phase:'downloaded',version:info.version,percent:100,message:'Atualização pronta. Instale quando quiser.'}));
 updater.on('error',error=>this.fail(error));}
 set(value){Object.assign(this.state,value);this.publish(this.read());return this.read();}
 read(){return {...this.state};}
 fail(error){const text=String(error?.message||''),code=String(error?.code||'');const unpublished=['ERR_UPDATER_NO_PUBLISHED_VERSIONS','ERR_UPDATER_LATEST_VERSION_NOT_FOUND'].includes(code)||/No published versions|No releases|Cannot find latest release/i.test(text);return this.set({phase:'error',message:code==='ERR_XML_MISSED_ELEMENT'?'O GitHub ainda não forneceu uma publicação de atualização válida.':unpublished?'Ainda não há uma versão publicada no GitHub.':/channel-file|latest.yml/i.test(text)?'A publicação está incompleta: falta o arquivo de atualização.':'Não foi possível concluir. Confira sua internet e tente novamente.'});}
 async check(){if(!this.enabled)return this.set({phase:'development',message:'A consulta fica disponível no programa instalado.'});if(['checking','downloading','downloaded'].includes(this.state.phase))return this.read();this.set({phase:'checking',version:'',percent:0,message:'Conferindo atualizações…'});try{await this.updater.checkForUpdates();}catch(error){this.fail(error);}return this.read();}
 async download(){if(!this.enabled||this.state.phase!=='available')return this.read();this.set({phase:'downloading',percent:0,message:'Baixando atualização…'});try{await this.updater.downloadUpdate();}catch(error){this.fail(error);}return this.read();}
 install(){if(!this.enabled||this.state.phase!=='downloaded')throw Error('Baixe uma atualização antes de instalar.');this.updater.quitAndInstall(true,true);}
}
module.exports={Updates};
