'use strict';
const fs=require('node:fs'),path=require('node:path');
const names={quotes:'Orçamentos',clients:'Clientes e histórico',images:'Imagens',projects:'Projetos',backups:'Backups',temporary:'Temporários',products:'Produtos'};
function folders(root){const result={};for(const [key,name] of Object.entries(names)){result[key]=path.join(root,name);fs.mkdirSync(result[key],{recursive:true});}return result;}
function snapshot(directory,data,productsDirectory){if(productsDirectory){const file=path.join(productsDirectory,'Produtos.json'),temporary=file+'.tmp';fs.writeFileSync(temporary,JSON.stringify({catalogs:data.catalogs||[],products:data.products||[]},null,2));fs.renameSync(temporary,file);}const target=path.join(directory,'Cadastros.json'),temp=target+'.tmp';fs.writeFileSync(temp,JSON.stringify({clients:data.clients,quotes:data.quotes},null,2));fs.renameSync(temp,target);}
function backupName(){return 'Criae3D-Utilities-Backup-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+require('node:crypto').randomBytes(3).toString('hex')+'.json';}
module.exports={folders,snapshot,backupName};
