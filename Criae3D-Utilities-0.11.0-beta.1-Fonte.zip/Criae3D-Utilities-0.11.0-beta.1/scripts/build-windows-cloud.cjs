'use strict';
// Reuse electron-builder's own validated NSIS uninstaller extraction on Linux.
// This avoids executing the 32-bit intermediate installer in Wine; it does not
// skip package checks, modify application code, or fabricate an uninstaller.
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const version=require(path.join(root,'package.json')).version;
const requireApp=require('node:module').createRequire(path.join(root,'package.json'));
const {WineVmManager}=requireApp('app-builder-lib/out/vm/WineVm');
const {UninstallerReader}=requireApp('app-builder-lib/out/targets/nsis/nsisUtil');
const original=WineVmManager.prototype.exec;
WineVmManager.prototype.exec=function(file,args,options){
 if(process.platform==='linux'&&path.dirname(file)===path.join(root,'dist')&&path.basename(file)===`Criae3D-Utilities-${version}-Instalar.exe`&&args.length===0&&options?.env?.__COMPAT_LAYER==='RunAsInvoker'){
  const target=file.replace(/\.exe$/,'.__uninstaller.exe');
  console.log('Extracting generated NSIS uninstaller with built-in UninstallerReader.');
  return UninstallerReader.exec(file,target);
 }
 return original.call(this,file,args,options);
};
const builder=requireApp('electron-builder');
builder.build({projectDir:root,targets:builder.Platform.WINDOWS.createTarget('nsis',builder.Arch.x64),publish:'never',config:{electronDownload:{cache:process.env.electron_config_cache||path.join(require('node:os').tmpdir(),'criae3d-electron-cache')}}}).catch(e=>{console.error(e);process.exitCode=1;});
