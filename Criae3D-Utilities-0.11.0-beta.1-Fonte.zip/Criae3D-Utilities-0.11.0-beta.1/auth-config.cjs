'use strict';
module.exports=Object.freeze({url:'https://vyifatgsbxigqckzxyvv.supabase.co',key:'sb_publishable_Y9BYGWBEy0rJc_k5KOU_Sw_Pxs9kSLP'});
