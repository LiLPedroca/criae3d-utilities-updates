# Ícones dos fatiadores

Usados somente para identificar os aplicativos compatíveis. As marcas pertencem aos respectivos titulares; não há afiliação ou endosso.

- Anycubic Slicer Next: `resources/images/logo_192px.png` da instalação oficial 2.0.0.3.
- OrcaSlicer: `resources/images/OrcaSlicer_128px.png` da instalação oficial.
- Bambu Studio: https://github.com/bambulab/BambuStudio/blob/master/resources/images/BambuStudio_128px.png
- UltiMaker Cura: https://github.com/Ultimaker/Cura/blob/main/packaging/icons/cura-icon_128x128.png
- PrusaSlicer: https://github.com/prusa3d/PrusaSlicer/blob/master/resources/icons/PrusaSlicer_128px.png
- Creality Print: https://github.com/CrealityOfficial/CrealityPrint/blob/master/resources/images/CrealityPrint_128px.png

Arquivos originais obtidos em 16/10/2026. Cores e proporções das marcas preservadas.
