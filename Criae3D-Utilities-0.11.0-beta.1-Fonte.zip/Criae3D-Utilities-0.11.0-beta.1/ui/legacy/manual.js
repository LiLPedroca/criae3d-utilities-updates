'use strict';
// Manual products share the existing order, currency arithmetic and PDF pipeline.
const manualPanel=document.createElement('section');
manualPanel.className='card manual-panel';
manualPanel.hidden=true;
manualPanel.innerHTML=`<h2>Produto manual</h2><p class="hint">Marque os campos que deseja preencher e mostrar. A quantidade informada aparece quando a opção Quantidade está marcada na tela do orçamento. Quantidade e preço sempre são usados no total.</p><form id="manualForm" novalidate>
<label><input type="checkbox" data-manual-show="name" checked> Nome no orçamento</label><div class="input"><input id="manualName" maxlength="120" placeholder="Nome do produto"></div>
<label for="manualQuantity">Quantidade</label><div class="input"><input id="manualQuantity" inputmode="numeric" value="1"><span class="unit">un.</span></div>
<label><input type="checkbox" data-manual-show="weight"> Peso por unidade</label><div class="input"><input id="manualWeight" inputmode="decimal" disabled><span class="unit">g</span></div>
<div class="manual-dimensions">
<div><label><input type="checkbox" data-manual-show="height"> Altura</label><div class="input"><input id="manualHeight" inputmode="decimal" disabled><span class="unit">cm</span></div></div>
<div><label><input type="checkbox" data-manual-show="width"> Largura</label><div class="input"><input id="manualWidth" inputmode="decimal" disabled><span class="unit">cm</span></div></div>
<div><label><input type="checkbox" data-manual-show="length"> Comprimento</label><div class="input"><input id="manualLength" inputmode="decimal" disabled><span class="unit">cm</span></div></div></div>
<label for="manualPriceMode">Tipo de preço informado</label><select id="manualPriceMode"><option value="lot">Total do lote</option><option value="unit">Por unidade</option></select><p class="hint">Total do lote: R$ 120 para 10 peças = R$ 12 por unidade. Por unidade: R$ 120 para cada peça = R$ 1.200 no total.</p><label><input type="checkbox" data-manual-show="unit" checked> Mostrar preço por unidade no orçamento</label><div class="input"><input id="manualPrice" inputmode="decimal" placeholder="0,00"><span class="unit">R$</span></div>
<p id="manualError" class="error" role="alert" hidden></p><button type="submit" id="saveManual">Adicionar ao pedido</button> <button type="button" id="cancelManual">Cancelar</button></form>`;
const manualButton=document.createElement('button');
manualButton.id='addManualProduct';manualButton.type='button';manualButton.textContent='Adicionar produto manualmente';
document.getElementById('addProduct').after(manualButton);
document.querySelector('main').append(manualPanel);
let manualEditing=-1;
const manualFields={name:'manualName',quantity:'manualQuantity',weight:'manualWeight',height:'manualHeight',width:'manualWidth',length:'manualLength',unit:'manualPrice'};
function manualOptions(){return Object.fromEntries([...manualPanel.querySelectorAll('[data-manual-show]')].map(el=>[el.dataset.manualShow,el.checked]));}
function syncManual(){const s=manualOptions();for(const key of ['name','weight','height','width','length'])document.getElementById(manualFields[key]).disabled=!s[key];}
function closeManual(){manualPanel.hidden=true;manualEditing=-1;editing=-1;document.getElementById('addProduct').disabled=false;renderProducts();}
function openManual(index=-1){if(editing>=0&&manualPanel.hidden)return;manualEditing=index;editing=index;document.getElementById('addProduct').disabled=true;manualPanel.hidden=false;document.getElementById('manualError').hidden=true;const p=index>=0?products[index]:null;for(const [key,id] of Object.entries(manualFields))document.getElementById(id).value=p?.inputs[key]??(key==='quantity'?'1':'');for(const el of manualPanel.querySelectorAll('[data-manual-show]'))el.checked=p?p.sale.show[el.dataset.manualShow]:['name','quantity','unit'].includes(el.dataset.manualShow);document.getElementById('saveManual').textContent=p?'Salvar produto':'Adicionar ao pedido';document.getElementById('manualPriceMode').value=p?.inputs.priceMode|| (p?'unit':'lot');syncManual();quoteButton.disabled=true;manualPanel.scrollIntoView({behavior:'smooth',block:'center'});document.getElementById('manualName').focus();}
manualButton.addEventListener('click',()=>openManual());
// Prevent changing the order underneath an open manual editor.
document.getElementById('products').addEventListener('click',e=>{if(!manualPanel.hidden)e.stopImmediatePropagation();},true);
quoteButton.addEventListener('click',e=>{if(!manualPanel.hidden)e.stopImmediatePropagation();},true);
document.getElementById('cancelManual').addEventListener('click',closeManual);
manualPanel.addEventListener('change',syncManual);
document.getElementById('manualForm').addEventListener('submit',e=>{e.preventDefault();try{
 const show=manualOptions(),inputs=Object.fromEntries(Object.entries(manualFields).map(([k,id])=>[k,document.getElementById(id).value.trim()]));
 if(show.name&&!inputs.name)throw Error('Preencha o nome ou desmarque sua exibição.');
 if(!/^\d{1,7}$/.test(inputs.quantity)||Number(inputs.quantity)<1||Number(inputs.quantity)>1000000)throw Error('Quantidade: use um inteiro de 1 a 1.000.000.');
 if(!/^\d{1,9}([.,]\d{1,2})?$/.test(inputs.unit))throw Error('Preço: informe reais com até duas casas decimais, sem separador de milhar.');
 inputs.priceMode=document.getElementById('manualPriceMode').value;const price=parseDecimal(inputs.unit),quantity=Number(inputs.quantity),total=inputs.priceMode==='lot'?price:mul(price,R(quantity));
 if(show.weight&&inputs.weight){try{parseDecimal(inputs.weight);}catch{throw Error('Peso: informe um valor válido em gramas.');}}
 const dimensionLabels={height:'Altura',width:'Largura',length:'Comprimento'};
 const dimensions=[];for(const [key,label] of Object.entries(dimensionLabels)){if(show[key]&&inputs[key]){try{parseDecimal(inputs[key]);}catch{throw Error(label+': informe uma medida válida em cm ou deixe em branco.');}dimensions.push(label+': '+inputs[key].replace('.',',')+' cm');}}
 if(manualEditing<0&&products.length>=100)throw Error('Limite de 100 produtos por pedido.');
 const p={manual:true,inputs,sale:{name:inputs.name||'Produto',quantity,total:{n:total.n.toString(),d:total.d.toString()},show:{...show,dimensions:dimensions.length>0},weight:show.weight&&inputs.weight?inputs.weight.replace('.',',')+' g':'',dimensions:dimensions.join(' · ')}};
 if(manualEditing>=0)products[manualEditing]=p;else products.push(p);closeManual();
 }catch(error){const el=document.getElementById('manualError');el.textContent=error.message;el.hidden=false;}});
// Keep edits of manual items out of the calculation form.
document.getElementById('products').addEventListener('click',e=>{const row=e.target.closest('.product-row');if(!row)return;const index=[...row.parentElement.children].indexOf(row);if(products[index]?.manual&&e.target.textContent==='Editar'){e.stopImmediatePropagation();openManual(index);}},true);
