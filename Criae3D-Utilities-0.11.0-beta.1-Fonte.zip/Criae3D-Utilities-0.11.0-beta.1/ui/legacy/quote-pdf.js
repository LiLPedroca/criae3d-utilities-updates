'use strict';
(function(root){
async function createQuotePdf(q,assets){
  const P=root.PDFLib,{PDFDocument,StandardFonts,rgb}=P;const doc=await PDFDocument.create();doc.setTitle('Orçamento - '+q.data.client);doc.setAuthor(q.data.companyName||'');doc.setCreator('Criae3D Utilities');
  const regular=await doc.embedFont(StandardFonts.Helvetica),bold=await doc.embedFont(StandardFonts.HelveticaBold);const logo=q.data.show.logo?await (assets.logo[0]===137?doc.embedPng(assets.logo):doc.embedJpg(assets.logo)):null;const qr=q.data.show.qr?await doc.embedPng(assets.qr):null;
  const dark=rgb(0,0,0),gray=rgb(.25,.25,.25),teal=dark;let page,y;const pages=[];
  const safe=text=>Array.from(String(text)).map(c=>{if(c==='\n')return c;if(c==='\t')return ' ';try{regular.encodeText(c);return c;}catch{return '?';}}).join('');
  function newPage(){page=doc.addPage();page.setSize(595.28,841.89);pages.push(page);y=790;if(pages.length>1){page.drawText('Criae3D | Orçamento (continuação)',{x:42,y,font:bold,size:12,color:dark});y-=30;}}
  function space(h){if(y-h<55)newPage();}
  function wrap(text,font,size,width){const result=[];for(const para of safe(text).split('\n')){if(!para){result.push('');continue;}let line='';for(const char of para){if(font.widthOfTextAtSize(line+char,size)>width&&line){const last=line.lastIndexOf(' ');if(last>0){result.push(line.slice(0,last));line=line.slice(last+1)+char;}else{result.push(line);line=char;}}else line+=char;}result.push(line);}return result;}
  function text(value,{font=regular,size=10,color=dark,indent=0,width=511}={}){for(const line of wrap(value,font,size,width-indent)){space(size*1.28);if(line)page.drawText(line,{x:42+indent,y,font,size,color});y-=size*1.28;}}
  newPage();
  function box(x,top,w,h,fill){page.drawRectangle({x,y:top-h,width:w,height:h,borderColor:dark,borderWidth:.6,...(fill?{color:fill}:{})});}
  function draw(v,x,top,size=10,font=regular,color=dark){page.drawText(safe(v),{x,y:top-size-3,font,size,color});}
  const groups=root.QuoteModel.sections(q),s=q.data.show,company=groups.find(g=>g.title==='Criae3D');
  const companyLines=(company?.rows||[]).flatMap(([a,b])=>wrap((a?a+': ':'')+b,regular,9,logo?232:370));
  const stamps=[];if(s.date)stamps.push(['Criado em',q.stamp.issued]);if(s.number&&q.data.number.trim())stamps.push(['Orçamento nº',q.data.number]);if(s.validity)stamps.push(['Válido até',q.stamp.validUntil]);
  const stampLines=stamps.map(([a,b])=>[a,...wrap(b,bold,9,96)]),headerHeight=Math.max(82,companyLines.length*12+16,stampLines.reduce((n,a)=>n+a.length*12+8,0));
  if(logo||companyLines.length)box(42,y,stamps.length?398:511,headerHeight);if(stamps.length)box(443,y,110,headerHeight);
  if(logo){const size=logo.scaleToFit(120,headerHeight-16);page.drawImage(logo,{x:50,y:y-8-size.height,width:size.width,height:size.height});}
  companyLines.forEach((t,i)=>draw(t,logo?190:50,y-6-i*12,9));let sy=y;for(const lines of stampLines){const h=lines.length*12+8;box(443,sy,110,h);lines.forEach((t,i)=>draw(t,449,sy-2-i*12,9,i?bold:regular));sy-=h;}
  if(logo||companyLines.length||stamps.length)y-=headerHeight+8;draw('Orçamento',244,y,20,bold);y-=34;
  function borderedRows(values){for(const value of values)for(const t of wrap(value,regular,10,499)){space(15);box(42,y,511,15);draw(t,48,y,9);y-=15;}y-=4;}
  const client=groups.find(g=>g.title==='Cliente');space(40);box(42,y,511,19,dark);draw('Cliente',48,y,10,bold,rgb(1,1,1));y-=19;borderedRows(client.rows.map(([a,b])=>a+': '+b));
  const cols=[{title:'DESCRIÇÃO',width:511-(s.quantity?45:0)-(s.unit?92:0)-105},...(s.quantity?[{title:'QTD',width:45}]:[]),...(s.unit?[{title:'PREÇO UNIT.',width:92}]:[]),{title:'TOTAL',width:105}];
  function tableHeader(){space(38);let x=42;for(const c of cols){box(x,y,c.width,20,dark);draw(c.title,x+5,y,9,bold,rgb(1,1,1));x+=c.width;}y-=20;}
  tableHeader();for(const product of q.items){let first=true;for(const t of wrap(root.QuoteModel.itemDescription(product,s),regular,9,cols[0].width-10)){if(y-16<55){newPage();tableHeader();}let x=42;for(let i=0;i<cols.length;i++){const c=cols[i],v=i===0?t:first?(c.title==='QTD'?String(product.quantity):c.title==='PREÇO UNIT.'?(product.show?.unit===false?'':root.QuoteModel.currency(product.unit)):root.QuoteModel.currency(product.subtotal)):'';box(x,y,c.width,16);let size=9;while(size>5&&regular.widthOfTextAtSize(safe(v),size)>c.width-10)size--;draw(v,x+5,y,size);x+=c.width;}y-=16;first=false;}}y-=8;
  const extra=(groups.find(g=>g.title==='Peça / projeto')?.rows||[]).filter(([a])=>!['Nome','Quantidade','Preço por unidade'].includes(a));

  const totals=[['Subtotal',root.QuoteModel.currency(q.subtotal)],...(q.data.discountEnabled?[['Desconto','- '+root.QuoteModel.currency(q.discount)]]:[]),...(q.data.delivery==='shipping'?[['Frete',root.QuoteModel.currency(q.freight)]]:q.unknown?[['Frete','A combinar']]:[]),[q.unknown?'Total (sem frete)':'Total final',root.QuoteModel.currency(q.total)]];
  space(totals.length*24+8);for(const [label,v] of totals){box(301,y,132,24);box(433,y,120,24);draw(label,307,y,10,label.startsWith('Total')?bold:regular);let size=11;while(size>5&&bold.widthOfTextAtSize(v,size)>108)size--;draw(v,439,y,size,bold);y-=24;}y-=10;
  if(extra.length)groups.push({title:'Detalhes do pedido',rows:extra});
  for(const title of ['Detalhes do pedido','Condições','Sinal e saldo','Observações']){const g=groups.find(g=>g.title===title);if(g){space(40);box(42,y,511,19,dark);draw(title,48,y,10,bold,rgb(1,1,1));y-=19;borderedRows(g.rows.map(([a,b])=>(a?a+': ':'')+b));}}
  if(qr){space(96);page.drawImage(qr,{x:42,y:y-88,width:88,height:88});draw('Conheça nossa loja',140,y-22,10,bold);draw('criae3d.com.br',140,y-40);y-=96;}
  for(let i=0;i<pages.length;i++)pages[i].drawText('Página '+(i+1)+' de '+pages.length,{x:475,y:28,font:regular,size:9,color:gray});
  return doc.save();
}
root.createQuotePdf=createQuotePdf;
})(typeof window==='undefined'?this:window);
