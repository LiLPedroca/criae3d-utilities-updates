'use strict';
let utilitiesInitialized=false;
const saveCatalogButton=document.createElement('button');saveCatalogButton.id='saveCalculatorCatalog';saveCatalogButton.type='button';saveCatalogButton.textContent='Salvar produtos no catálogo';quoteButton.insertAdjacentElement('afterend',saveCatalogButton);
saveCatalogButton.title='Preço unitário salvo com arredondamento para centavos.';
saveCatalogButton.onclick=()=>{if(editing>=0||!manualPanel.hidden){const error=document.getElementById('error');error.hidden=false;error.textContent='Conclua ou cancele a edição antes de salvar no catálogo.';return;}const current=products.length?null:currentProduct();if(!products.length&&!current)return;const items=(products.length?products:[current]).map(product=>({...product.sale,weight:product.manual?product.sale.weight:grams(div(parseDecimal(product.inputs.weight),parseDecimal(product.inputs.quantity)))}));saveCatalogButton.disabled=true;window.parent.postMessage({type:'utilities:catalog',order:{items}},'*');};
window.addEventListener('message',event=>{if(event.source===window.parent&&event.data?.type==='utilities:catalog-result')saveCatalogButton.disabled=false;});
window.calculatorHasPending=()=>products.length>0||editing>=0||!manualPanel.hidden||document.getElementById('name').value.trim()!==''||document.getElementById('laborBonus').checked||fields.some(key=>document.getElementById(key).value!==defaults[key]);
function confirmCalculatorAction(){const count=products.length,wasEditing=editing>=0;queueMicrotask(()=>{if(products.length>count||(wasEditing&&editing<0))window.parent.postMessage({type:'utilities:feedback',message:'Produto pronto no pedido. Envie ao orçamento para salvar.'},'*');});}
document.getElementById('addProduct').addEventListener('click',confirmCalculatorAction,true);
document.getElementById('manualForm').addEventListener('submit',confirmCalculatorAction,true);
const sizeObserver=new ResizeObserver(()=>window.parent.postMessage({type:'utilities:height',height:document.body.scrollHeight+30},'*'));sizeObserver.observe(document.body);
quoteButton.addEventListener('click',event=>{
 event.stopImmediatePropagation();if(editing>=0||!manualPanel.hidden)return;
 const current=products.length?null:currentProduct();if(!products.length&&!current)return;
 window.parent.postMessage({type:'utilities:quote',order:{items:products.length?products.map(p=>p.sale):[current.sale]}},'*');
},true);
window.addEventListener('message',event=>{
 if(event.source!==window.parent||event.data?.type!=='utilities:settings')return;
 for(const key of ['filament','machine','watts','tariff','labor','markup']){const value=String(event.data.defaults?.[key]||'0');const input=document.getElementById(key),untouched=!utilitiesInitialized||input.value===defaults[key];defaults[key]=value;if(untouched)input.value=value;}
 document.documentElement.dataset.theme=event.data.theme==='light'?'light':'dark';document.documentElement.dataset.appearance=event.data.theme;
 for(const [key,value] of Object.entries(event.data.colors||{}))if(/^#[0-9a-f]{6}$/i.test(value))document.documentElement.style.setProperty('--'+key,value);
 document.documentElement.dataset.motion=event.data.reduceMotion?'off':'on';utilitiesInitialized=true;update();
});
