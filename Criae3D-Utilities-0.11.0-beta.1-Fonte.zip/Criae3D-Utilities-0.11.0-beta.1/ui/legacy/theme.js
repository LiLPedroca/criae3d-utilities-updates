'use strict';
(function(){
 const button=document.getElementById('themeToggle');let dark=false;
 try{dark=localStorage.getItem('criae3d-theme')==='dark';}catch{}
 function apply(){document.documentElement.dataset.theme=dark?'dark':'light';button.textContent=dark?'Modo claro':'Modo escuro';button.setAttribute('aria-pressed',String(dark));}
 button.addEventListener('click',()=>{dark=!dark;apply();try{localStorage.setItem('criae3d-theme',dark?'dark':'light');}catch{}});
 window.addEventListener('storage',e=>{if(e.key==='criae3d-theme'){dark=e.newValue==='dark';apply();}});apply();
})();
