'use strict';
(function(root){
 const money=typeof module!=='undefined'&&module.exports?require('./legacy/quote-model.js'):root.QuoteModel;
 const measure=value=>{const text=String(value??'').trim();if(text&&!/^\d{1,9}([.,]\d{1,6})?$/.test(text))throw Error('Informe medidas positivas ou zero, sem a unidade.');return text.replace('.',',');};
 function validate(product){
  if(!product||typeof product.id!=='string'||!product.id||product.id.length>100||typeof product.name!=='string'||!product.name.trim()||product.name.length>120||/[\x00-\x1f\x7f]/.test(product.name))throw Error('Nome de produto inválido (até 120 caracteres).');
  if(typeof product.category!=='string'||product.category.length>80||typeof product.unitCents!=='string'||!/^\d{1,11}$/.test(product.unitCents))throw Error('Categoria ou preço do produto inválido.');
  for(const key of ['weight','height','width','length']){if(typeof product[key]!=='string')throw Error('Medida do produto inválida.');measure(product[key]);}
  if(typeof product.details!=='string'||product.details.length>180)throw Error('Detalhes de dimensões inválidos.');
  if(!product.show||['name','unit','weight','dimensions'].some(k=>typeof product.show[k]!=='boolean'))throw Error('Selecione as informações exibidas do produto.');
  return structuredClone(product);
 }
 function create(values,identity,previous){
  const product={id:identity,name:String(values.name??'').trim(),category:String(values.category??'').trim(),unitCents:money.amount(values.price||'0').toString(),details:String(values.details??'').trim(),show:Object.fromEntries(['name','unit','weight','dimensions'].map(k=>[k,values.show?.[k]!==false]))};
  for(const key of ['weight','height','width','length'])product[key]=measure(values[key]);
  if(previous?.catalogId)product.catalogId=previous.catalogId;
  product.createdAt=previous?.createdAt||new Date().toISOString();product.updatedAt=new Date().toISOString();return validate(product);
 }
 function sale(product,quantity,override){
  product=validate(product);const value=String(quantity).trim();if(!/^\d+$/.test(value)||!Number.isSafeInteger(Number(value))||Number(value)<1||Number(value)>1000000)throw Error('Informe uma quantidade inteira entre 1 e 1.000.000.');
  const cents=override===undefined?BigInt(product.unitCents):money.amount(override),dimensions=[...['height','width','length'].filter(k=>product[k]).map(k=>({height:'Altura',width:'Largura',length:'Comprimento'})[k]+': '+product[k]+' cm'),product.details].filter(Boolean).join(' · ');
  if(dimensions.length>180)throw Error('As dimensões são muito longas. Reduza os detalhes do produto.');
  return {name:product.name,quantity:Number(value),total:{n:(cents*BigInt(value)).toString(),d:'100'},weight:product.weight?product.weight+' g':'',dimensions,show:structuredClone(product.show)};
 }
 function fromSale(item,identity){
  const source=money.readSale(item),n=BigInt(source.total.n)*100n,d=BigInt(source.total.d)*BigInt(source.quantity),cents=(n*2n+d)/(d*2n);
  const values={name:source.name||'Produto',price:(cents/100n)+'.'+(cents%100n).toString().padStart(2,'0'),weight:source.weight.replace(/\s*g$/i,''),details:source.dimensions,show:source.show};
  const pattern=/^(Altura|Largura|Comprimento):\s*(\d+(?:[.,]\d+)?)\s*cm$/i,parts=source.dimensions.split(' · ');
  if(source.dimensions&&parts.every(p=>pattern.test(p))){values.details='';for(const part of parts){const match=part.match(pattern);values[({altura:'height',largura:'width',comprimento:'length'})[match[1].toLowerCase()]]=match[2];}}
  return create(values,identity);
 }
 const api={create,validate,sale,fromSale,price:product=>(BigInt(product.unitCents)/100n)+','+(BigInt(product.unitCents)%100n).toString().padStart(2,'0')};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.Catalog=api;
})(typeof window==='undefined'?this:window);
