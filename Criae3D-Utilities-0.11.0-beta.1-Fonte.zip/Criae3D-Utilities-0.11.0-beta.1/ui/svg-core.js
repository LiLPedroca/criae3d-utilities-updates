'use strict';
(function(root){
function vectorize(image,options,tracer){
 const {width,height}=image;if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width*height>2400000||image.data.length!==width*height*4)throw Error('Imagem inválida ou muito grande para esta versão beta.');
 const threshold=Number(options.threshold),smooth=Number(options.smooth),omit=Number(options.omit),mm=Number(options.widthMm);
 if(!Number.isFinite(threshold)||threshold<0||threshold>255||!Number.isFinite(smooth)||smooth<0||smooth>3||!Number.isFinite(omit)||omit<0||omit>100||!Number.isFinite(mm)||mm<1||mm>2000)throw Error('Confira os ajustes e a largura (1 a 2000 mm).');

 const data=new Uint8ClampedArray(image.data.length);let count=0,minX=width,minY=height,maxX=-1,maxY=-1;
 for(let i=0;i<data.length;i+=4){const a=image.data[i+3]/255,gray=(image.data[i]*.2126+image.data[i+1]*.7152+image.data[i+2]*.0722)*a+255*(1-a);const selected=a>.05&&(options.invert?gray>threshold:gray<threshold);let v=selected?0:255;data[i]=data[i+1]=data[i+2]=v;data[i+3]=255;if(selected){count++;const px=(i/4)%width,py=Math.floor(i/4/width);minX=Math.min(minX,px);minY=Math.min(minY,py);maxX=Math.max(maxX,px);maxY=Math.max(maxY,py);}}
 if(!count)throw Error('Nenhum contorno encontrado. Ajuste o limiar ou inverta a seleção.');
 const settings={pal:[{r:0,g:0,b:0,a:255},{r:255,g:255,b:255,a:255}],colorquantcycles:1,colorsampling:0,ltres:smooth,qtres:smooth,pathomit:omit,rightangleenhance:false,strokewidth:0,roundcoords:6,viewbox:true,scale:1,desc:false};
 // Trace only the useful region, retaining the source pixels and a white guard border.
 const offsetX=minX-2,offsetY=minY-2,traceWidth=maxX-minX+5,traceHeight=maxY-minY+5,cropped=new Uint8ClampedArray(traceWidth*traceHeight*4);cropped.fill(255);
 for(let y=minY;y<=maxY;y++){const start=(y*width+minX)*4;cropped.set(data.subarray(start,start+(maxX-minX+1)*4),((y-offsetY)*traceWidth+2)*4);}
 const traced=tracer.imagedataToTracedata({width:traceWidth,height:traceHeight,data:cropped},settings);
 for(let i=0;i<traced.layers.length;i++)if(traced.palette[i].r>127)traced.layers[i]=[];
 // Bounds include quadratic extrema, not the control polygon or bitmap margins.
 const bounds={minX:Infinity,minY:Infinity,maxX:-Infinity,maxY:-Infinity};
 const point=(x,y)=>{bounds.minX=Math.min(bounds.minX,x);bounds.maxX=Math.max(bounds.maxX,x);bounds.minY=Math.min(bounds.minY,y);bounds.maxY=Math.max(bounds.maxY,y);};
 for(const layer of traced.layers)for(const path of layer)for(const seg of path.segments){point(seg.x1,seg.y1);if(seg.type==='L')point(seg.x2,seg.y2);else{point(seg.x3,seg.y3);for(const axis of ['x','y']){const den=seg[axis+'1']-2*seg[axis+'2']+seg[axis+'3'],t=den?(seg[axis+'1']-seg[axis+'2'])/den:0;if(t>0&&t<1){const q=k=>(1-t)**2*seg[k+'1']+2*(1-t)*t*seg[k+'2']+t*t*seg[k+'3'];point(q('x'),q('y'));}}}}
 const bw=bounds.maxX-bounds.minX,bh=bounds.maxY-bounds.minY;
 if(!(bw>0&&bh>0))throw Error('Os detalhes foram removidos pelo filtro. Reduza Remover pontos.');
 const heightMm=options.heightMm===undefined?mm*bh/bw:Number(options.heightMm);if(!Number.isFinite(heightMm)||heightMm<1||heightMm>2000)throw Error('Confira a altura (1 a 2000 mm).');
 for(const layer of traced.layers)for(const path of layer)for(const seg of path.segments)for(const k of Object.keys(seg)){if(/^x[123]$/.test(k))seg[k]=(seg[k]-bounds.minX)*mm/bw;else if(/^y[123]$/.test(k))seg[k]=(seg[k]-bounds.minY)*heightMm/bh;}
 traced.width=mm;traced.height=heightMm;
 let svg=tracer.getsvgstring(traced,settings),paths=(svg.match(/<path /g)||[]).length;
 if(!paths)throw Error('Os detalhes foram removidos pelo filtro. Reduza Remover pontos.');
 svg=svg.replace('<svg ','<svg preserveAspectRatio="none" width="'+mm+'mm" height="'+Number(heightMm.toFixed(6))+'mm" ');
 return {svg,paths,width,height,widthMm:mm,heightMm,aspect:bw/bh,bounds:{minX:bounds.minX+offsetX,minY:bounds.minY+offsetY,maxX:bounds.maxX+offsetX,maxY:bounds.maxY+offsetY},processedPixels:traceWidth*traceHeight,coverage:count/(width*height)};
}
function resize(result,widthMm,heightMm){
 if(![widthMm,heightMm].every(v=>Number.isFinite(v)&&v>=1&&v<=2000))throw Error('Medidas inválidas.');
 const sx=widthMm/result.widthMm,sy=heightMm/result.heightMm;
 let svg=result.svg.replace(/d="([^"]*)"/g,(all,d)=>{let n=0;return 'd="'+d.replace(/-?(?:\d*\.)?\d+(?:e[-+]?\d+)?/gi,v=>String(Number((Number(v)*(n++%2?sy:sx)).toFixed(6))))+'"';});
 svg=svg.replace(/width="[^"]*mm"/,'width="'+widthMm+'mm"').replace(/height="[^"]*mm"/,'height="'+heightMm+'mm"').replace(/viewBox="[^"]*"/,'viewBox="0 0 '+widthMm+' '+heightMm+'"');
 return {...result,svg,widthMm,heightMm};
}
root.SvgConverter={vectorize,resize};if(typeof module==='object')module.exports=root.SvgConverter;
})(typeof self==='object'?self:globalThis);
