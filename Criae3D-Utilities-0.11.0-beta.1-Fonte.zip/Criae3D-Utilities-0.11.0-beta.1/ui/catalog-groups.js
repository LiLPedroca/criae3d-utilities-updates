'use strict';
(function(root){
 function migrate(source){
  const data=structuredClone(source);
  if(data.catalogs===undefined){
   data.catalogs=[];const categories=new Map();
   for(const product of data.products||[]){
    const name=product.category?.trim()||'Geral';
    if(!categories.has(name)){const catalog={id:'legacy-catalog-'+categories.size,name};categories.set(name,catalog.id);data.catalogs.push(catalog);}
    product.catalogId=categories.get(name);
   }
  }
  return data;
 }
 function validate(data){
  if(!Array.isArray(data.catalogs)||data.catalogs.length>10000)throw Error('Catálogos inválidos ou limite excedido.');
  const ids=new Set();for(const c of data.catalogs){if(!c||typeof c.id!=='string'||!c.id||c.id.length>100||ids.has(c.id)||typeof c.name!=='string'||!c.name.trim()||c.name.length>80||/[\x00-\x1f\x7f]/.test(c.name))throw Error('Nome de catálogo inválido ou duplicado.');ids.add(c.id);}
  for(const p of data.products||[])if(p.catalogId!==undefined&&!ids.has(p.catalogId))throw Error('Catálogo do produto não encontrado.');
  return data;
 }
 const api={migrate,validate};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.CatalogGroups=api;
})(typeof window==='undefined'?this:window);
