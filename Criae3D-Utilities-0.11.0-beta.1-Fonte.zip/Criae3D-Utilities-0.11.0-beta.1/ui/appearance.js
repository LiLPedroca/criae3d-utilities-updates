'use strict';
(function(root){
 const valid=hex=>/^#[0-9a-f]{6}$/i.test(hex);
 const rgb=hex=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
 const hex=channels=>'#'+channels.map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');
 function luminance(color){return rgb(color).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((sum,v,i)=>sum+v*[.2126,.7152,.0722][i],0);}
 function contrast(a,b){const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
 function readable(color,dark){if(!valid(color))throw Error('Use uma cor hexadecimal com 6 dígitos.');const bg=dark?'#171a20':'#ffffff',base=rgb(color),target=dark?255:0;for(let step=0;step<=100;step++){const candidate=hex(base.map(v=>v+(target-v)*step/100));if(contrast(candidate,bg)>=4.5)return candidate;}return dark?'#ffffff':'#000000';}
 const foreground=color=>contrast(color,'#101216')>=contrast(color,'#ffffff')?'#101216':'#ffffff';
 const api={valid,readable,foreground,contrast};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.Appearance=api;
})(typeof window==='undefined'?this:window);
