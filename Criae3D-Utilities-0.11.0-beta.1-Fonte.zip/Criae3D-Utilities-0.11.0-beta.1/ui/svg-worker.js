'use strict';
importScripts('vendor/imagetracer.js','svg-core.js');
onmessage=event=>{try{postMessage({ok:true,...SvgConverter.vectorize(event.data.image,event.data.options,ImageTracer)});}catch(error){postMessage({ok:false,message:error.message});}};
