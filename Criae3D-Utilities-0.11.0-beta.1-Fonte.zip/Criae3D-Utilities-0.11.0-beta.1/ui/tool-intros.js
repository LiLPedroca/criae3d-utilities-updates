'use strict';
const toolPresentations={
 quotes:{title:'Seu orçamento, passo a passo',text:'Do primeiro contato ao PDF, tudo em uma sequência simples.',benefits:['Preencha Cliente, Produtos, Condições e Finalizar','Acompanhe a prévia do PDF durante o preenchimento','Aplique descontos em reais ou porcentagem'],action:'Criar meus orçamentos'},
 clients:{title:'Seus clientes, sempre por perto',text:'Encontre os contatos e acompanhe o que já foi feito para cada cliente.',benefits:['Identifique seus clientes pelo nome e celular','Cadastre o essencial e complete os detalhes quando precisar','Consulte o histórico e comece um orçamento vinculado'],action:'Conhecer meus clientes'},
 products:{title:'Um lugar para cada produto',text:'Organize seus produtos em catálogos para encontrar tudo com facilidade.',benefits:['Crie catálogos para os seus grupos de produtos','Cadastre, edite e organize preços e informações','Reutilize os produtos ao montar seus orçamentos'],action:'Explorar meus catálogos'},
 backup:{title:'Seu trabalho bem protegido',text:'Guarde uma cópia dos seus cadastros para recuperar quando precisar.',benefits:['Exporte seus dados em um backup','Restaure uma cópia quando precisar recuperar os cadastros','Consulte e organize as pastas dos seus arquivos'],action:'Conhecer o backup'}
};
function showToolPresentation(key){
 const content=toolPresentations[key];
 if(!content||database.settings.toolIntroDismissed?.[key]||$('toolIntro'))return;
 const dialog=document.createElement('dialog');dialog.id='toolIntro';dialog.setAttribute('aria-labelledby','toolIntroTitle');dialog.setAttribute('aria-describedby','toolIntroText');
 dialog.innerHTML='<div class="dialog-symbol">'+svgIcon(key)+'</div><h2 id="toolIntroTitle">'+esc(content.title)+'</h2><p id="toolIntroText" class="muted">'+esc(content.text)+'</p><ul class="intro-benefits">'+content.benefits.map(text=>'<li>'+esc(text)+'</li>').join('')+'</ul><label><input type="checkbox" id="dismissToolIntro"> Não mostrar novamente esta mensagem</label><p id="toolIntroError" role="alert"></p><div class="actions"><button type="button" class="primary primary-action" id="enterTool">'+esc(content.action)+' →</button></div>';
 document.body.append(dialog);let busy=false;
 const close=async()=>{
  if(busy)return;busy=true;$('enterTool').disabled=true;$('dismissToolIntro').disabled=true;$('toolIntroError').textContent='';
  try{
   if($('dismissToolIntro').checked){const previous=database.settings.toolIntroDismissed;database.settings.toolIntroDismissed={...previous,[key]:true};try{await persist();}catch(e){if(previous===undefined)delete database.settings.toolIntroDismissed;else database.settings.toolIntroDismissed=previous;throw e;}}
   dialog.close();dialog.remove();
  }catch(e){$('toolIntroError').textContent='Não foi possível salvar a preferência. Tente novamente.';}
  finally{busy=false;if(dialog.isConnected){$('enterTool').disabled=false;$('dismissToolIntro').disabled=false;}}
 };
 dialog.addEventListener('cancel',e=>{e.preventDefault();close();});$('enterTool').onclick=close;dialog.showModal();enhanceSwitches(document);
}
const navigateWithPresentations=navigate;
navigate=function(next){const result=navigateWithPresentations(next);queueMicrotask(()=>{if(route===next)showToolPresentation(next);});return result;};

// beforeunload still protects pending forms; the main process requests this themed dialog.
function showUnsavedCloseDialog(){
 if($('unsavedCloseDialog'))return;
 const dialog=document.createElement('dialog');dialog.id='unsavedCloseDialog';dialog.setAttribute('aria-labelledby','unsavedCloseTitle');dialog.setAttribute('aria-describedby','unsavedCloseText');
 dialog.innerHTML='<h2 id="unsavedCloseTitle">Você tem alterações não salvas</h2><p id="unsavedCloseText" class="muted">Deseja continuar editando ou sair sem salvar?</p><p class="hint">Ao sair, o preenchimento não salvo será descartado. Os dados já salvos serão preservados.</p><p id="unsavedCloseError" role="alert"></p><div class="actions"><button type="button" class="primary primary-action" id="keepEditing" autofocus>Continuar editando</button><button type="button" id="discardAndClose">Sair sem salvar</button></div>';
 document.body.append(dialog);let busy=false;
 const choose=async discard=>{
  if(busy)return;busy=true;$('keepEditing').disabled=true;$('discardAndClose').disabled=true;$('unsavedCloseError').textContent='';
  try{
   if(discard){$('discardAndClose').textContent='Aguarde…';await saveQueue.catch(()=>{});}
   if(discard)closeApproved=true;
   const accepted=await desktop.closeChoice(discard?'discard':'cancel');
   if(!accepted)throw Error('Tente fechar a janela novamente.');
   if(!discard){dialog.close();dialog.remove();}
  }catch(e){closeApproved=false;$('unsavedCloseError').textContent='Não foi possível fechar com segurança: '+e.message;}
  finally{busy=false;if(dialog.isConnected){$('keepEditing').disabled=false;$('discardAndClose').disabled=false;$('discardAndClose').textContent='Sair sem salvar';}}
 };
 $('keepEditing').onclick=()=>choose(false);$('discardAndClose').onclick=()=>choose(true);dialog.addEventListener('cancel',e=>{e.preventDefault();choose(false);});dialog.showModal();
}
if(desktop.onCloseRequested)desktop.onCloseRequested(async()=>{
 if($('unsavedCloseDialog'))return;
 if(!savePending&&!saveFailed&&!formDirty()){closeApproved=true;try{if(!await desktop.closeChoice('clean'))closeApproved=false;}catch(e){closeApproved=false;notice('Não foi possível fechar: '+e.message,'error');}return;}
 showUnsavedCloseDialog();
});

