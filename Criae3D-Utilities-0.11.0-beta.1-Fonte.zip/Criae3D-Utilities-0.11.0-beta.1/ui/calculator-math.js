'use strict';
(function(root){
 const gcd=(a,b)=>{while(b){[a,b]=[b,a%b];}return a;};
 const rational=(n,d=1n)=>{n=BigInt(n);d=BigInt(d);if(d<=0n||n<0n)throw Error('Valor inválido.');const g=gcd(n,d);return {n:n/g,d:d/g};};
 function decimal(value,label='Valor'){const s=String(value??'').trim();if(!/^\d{1,9}(?:[.,]\d{1,6})?$/.test(s))throw Error(label+': informe um número de zero a 999.999.999, com até 6 casas decimais.');const[a,b='']=s.replace(',','.').split('.');return rational(BigInt(a+b),10n**BigInt(b.length));}
 const add=(a,b)=>rational(a.n*b.d+b.n*a.d,a.d*b.d);
 const mul=(a,b)=>rational(a.n*b.n,a.d*b.d);
 const div=(a,b)=>{if(b.n===0n)throw Error('Não é possível dividir por zero.');return rational(a.n*b.d,a.d*b.n);};
 const round=(a,places=2)=>{const scale=10n**BigInt(places);return (a.n*scale*2n+a.d)/(2n*a.d);};
 function display(a,places=6){const scale=10n**BigInt(places),n=round(a,places);return (n/scale).toString()+(places?','+(n%scale).toString().padStart(places,'0').replace(/0+$/,''):'');}
 function text(a,places=6){return display(a,places).replace(/,$/,'');}
 function calculate(v){const x={};const labels={weight:'Peso total',quantity:'Quantidade',filament:'Preço do filamento',hours:'Horas',minutes:'Minutos',watts:'Consumo da impressora',tariff:'Tarifa de energia',machine:'Uso da impressora por hora',labor:'Mão de obra',markup:'Lucro sobre o custo'};for(const k of Object.keys(labels))x[k]=decimal(v[k],labels[k]);if(x.quantity.d!==1n||x.quantity.n<1n||x.quantity.n>1000000n)throw Error('Quantidade: informe um inteiro de 1 a 1.000.000.');if(x.hours.d!==1n||x.minutes.d!==1n||x.minutes.n>=60n)throw Error('Tempo: use horas inteiras e minutos de 0 a 59.');
 const time=add(x.hours,div(x.minutes,rational(60))),parts={filament:div(mul(x.weight,x.filament),rational(1000)),energy:div(mul(mul(time,x.watts),x.tariff),rational(1000)),machine:mul(time,x.machine),labor:x.labor};
 const cost=Object.values(parts).reduce(add,rational(0)),profit=div(mul(cost,x.markup),rational(100)),price=add(cost,profit),unitCost=div(cost,x.quantity),unitProfit=div(profit,x.quantity),unitPrice=div(price,x.quantity),unitWeight=div(x.weight,x.quantity);
 if(round(price)>99999999999n||round(unitPrice)>99999999999n)throw Error('O preço calculado excede o limite de R$ 999.999.999,99.');
 return {input:x,quantity:Number(x.quantity.n),time,parts,cost,profit,price,unitCost,unitProfit,unitPrice,unitWeight};}
 function sale(result,name){name=String(name??'').trim();if(!name||name.length>120||/[\x00-\x1f\x7f]/.test(name))throw Error('Informe o nome do produto (até 120 caracteres).');return {name,quantity:result.quantity,total:{n:result.price.n.toString(),d:result.price.d.toString()},weight:text(result.unitWeight)+' g',dimensions:'',show:{name:true,quantity:true,unit:true,weight:true,dimensions:true}};}
 const api={rational,decimal,add,mul,div,round,text,calculate,sale};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.CalculatorMath=api;
})(typeof window==='undefined'?this:window);
