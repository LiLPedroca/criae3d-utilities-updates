'use strict';
let closeApproved=false;
let noticeTimer,noticeSequence=0,tourStep=0,recoveryShown=false;
const tourSteps=[
 ['Bem-vindo ao seu espaço','Escolha uma ferramenta na tela inicial. Os recursos em breve mostram uma mensagem de desenvolvimento.','home'],
 ['Calcule com seus valores','Configure material, energia e mão de obra. Envie os produtos calculados para o rascunho do orçamento.','calculator'],
 ['Seu catálogo de produtos','Cadastre produtos com preço, peso e dimensões, ou salve itens da calculadora. Escolha o produto e a quantidade no orçamento sem preencher tudo novamente.','products'],
 ['Monte e acompanhe orçamentos','Adicione produtos, confira os valores e gere o PDF. Duplique pedidos anteriores e marque o status manualmente.','quotes'],
 ['Clientes e histórico','Cadastre seus clientes para preencher os próximos pedidos e consultar o histórico vinculado.','clients'],
 ['Tenha uma cópia de segurança','Crie e restaure backups na ferramenta de armazenamento. As atualizações também criam uma cópia interna antes de instalar.','backup']
];
function formDirty(){try{if($('calculatorFrame')?.contentWindow?.calculatorHasPending?.())return true;}catch{}return ['clientForm','itemForm','settingsForm','productForm','catalogPicker','accountForm','calculatorDefaultsForm','quoteDefaultsForm','profileSettingsForm'].some(key=>{const form=$(key);return form&&form.dataset.initial!==formFingerprint(form);});}
function formFingerprint(form){return JSON.stringify(Array.from(form.querySelectorAll('input:not([type=file]),select,textarea')).map(el=>[el.id,el.value,el.checked]));}
function rememberForms(){for(const key of ['clientForm','itemForm','settingsForm','productForm','catalogPicker','accountForm','calculatorDefaultsForm','quoteDefaultsForm','profileSettingsForm']){const form=$(key);if(form)form.dataset.initial=formFingerprint(form);}}
async function canLeave(){if(accountBusy){notice('Aguarde a operação de conta terminar.');return false;}if(saveFailed){try{await persist();}catch{return false;}}if(formDirty())return confirm('Há um formulário ou produtos da calculadora ainda não enviados ao orçamento. Deseja sair e descartar essas pendências? O rascunho do orçamento já salvo será preservado.');return true;}
async function go(next){if(next!=='svg'&&tools.slice(5).some(t=>t[0]===next)){showComingSoon(next);return;}if(next===route)return;if(await canLeave())navigate(next);}
function feedback(message,kind='info'){
 const host=$('notice'),sequence=++noticeSequence;clearTimeout(noticeTimer);host.replaceChildren();host.dataset.kind=kind;
 if(!message)return;
 const icon=document.createElement('span');icon.className='feedback-icon';icon.setAttribute('aria-hidden','true');icon.textContent=kind==='success'?'✓':kind==='error'?'!':'i';
 const text=document.createElement('span');text.textContent=message;const close=document.createElement('button');close.type='button';close.className='feedback-close';close.setAttribute('aria-label','Fechar aviso');close.textContent='×';close.onclick=()=>notice('');
 host.append(icon,text,close);host.style.animation='none';void host.offsetWidth;host.style.animation='';
 noticeTimer=setTimeout(()=>{if(sequence===noticeSequence)notice('');},kind==='error'?14000:6000);
}
function saveIndicator(){const host=$('draftStatus');if(host){host.textContent=saveFailed?'Não salvo — tente novamente':savePending?'Salvando rascunho…':draft().savedAt?'Rascunho salvo às '+new Date(draft().savedAt).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}):'O rascunho será salvo enquanto você preenche.';host.dataset.state=saveFailed?'error':savePending?'pending':'saved';}}
function releaseDialog(){$('releaseDialog').querySelector('.dialog-error')?.remove();const current=ReleaseInfo.releases[0];$('releaseTitle').textContent='Novidades · '+current.version;$('releaseBody').innerHTML='<p class="muted">'+esc(current.title)+'</p>'+current.groups.map(g=>'<section><h3>'+esc(g.title)+'</h3><ul>'+g.items.map(t=>'<li>'+esc(t)+'</li>').join('')+'</ul></section>').join('');$('releaseDialog').showModal();}
function showDialogError(dialog,error){let message=dialog.querySelector('.dialog-error');if(!message){message=document.createElement('p');message.className='dialog-error';message.setAttribute('role','alert');dialog.append(message);}message.textContent='Não foi possível salvar a preferência: '+error.message+'. Você pode tentar novamente.';}
async function acknowledgeRelease(){const previous=database.settings.seenRelease;database.settings.seenRelease=ReleaseInfo.version;try{await persist();$('releaseDialog').close();}catch(error){database.settings.seenRelease=previous;showDialogError($('releaseDialog'),error);}}
function startTour(){$('tourDialog').querySelector('.dialog-error')?.remove();tourStep=0;renderTour();$('tourDialog').showModal();}
function renderTour(){const [title,text]=tourSteps[tourStep];$('tourTitle').textContent=title;$('tourText').textContent=text;$('tourCounter').textContent='Passo '+(tourStep+1)+' de '+tourSteps.length;$('tourBack').disabled=tourStep===0;$('tourNext').textContent=tourStep===tourSteps.length-1?'Concluir':'Próximo';}
async function endTour(){const previous=database.settings.tourSeen;database.settings.tourSeen=true;try{await persist();$('tourDialog').close();notice('Seu espaço está pronto para explorar.','success');}catch(error){database.settings.tourSeen=previous;showDialogError($('tourDialog'),error);}}
$('releaseClose').onclick=acknowledgeRelease;$('releaseDialog').addEventListener('cancel',event=>{event.preventDefault();acknowledgeRelease();});
$('tourNext').onclick=()=>{if(tourStep===tourSteps.length-1)endTour();else{tourStep++;renderTour();}};$('tourBack').onclick=()=>{tourStep--;renderTour();};$('tourSkip').onclick=endTour;$('tourDialog').addEventListener('cancel',event=>{event.preventDefault();endTour();});
window.addEventListener('beforeunload',event=>{if(!closeApproved&&(savePending||saveFailed||formDirty())){event.preventDefault();event.returnValue=false;}});
window.addEventListener('unhandledrejection',event=>{event.preventDefault();notice('Não foi possível concluir a ação: '+(event.reason?.message||'tente novamente.'),'error');});
async function finishStartup(hadProfile){if(hadProfile&&database.settings.seenRelease!==ReleaseInfo.version)releaseDialog();else if(!hadProfile){database.settings.seenRelease=ReleaseInfo.version;await persist();}if(database.draft&&(database.draft.items.length||database.draft.data.client)&&!recoveryShown){recoveryShown=true;notice('Seu rascunho anterior foi recuperado. Abra Orçamentos para continuar.');}}
